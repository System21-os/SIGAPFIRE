/**
 * SIGAPApi.js - Firebase Architecture & Data Adapter for SIGAP Inventory System
 * Trans Cafe Gading Inventory System
 *
 * Implements 1:1 Parity with Code.gs for all 46 API Actions.
 * Supports Cloud Firestore, Firebase Authentication, Cloud Storage,
 * and robust local offline cache.
 */

(function(window) {
  'use strict';

  // Seed data from Code.gs initial master and system structure
  const DEFAULT_ADMIN = {
    username: 'admin',
    nama: 'Administrator',
    role: 'ADMIN',
    status: 'AKTIF',
    updatedAt: '16/09/2026 10:00',
    updatedBy: 'SYSTEM'
  };

  const DEFAULT_MASTER = [
    { namaItem: "[IF21300003]Buk Caramel Popcorn", displayName: "Buk Caramel Popcorn", uom: "pcs", altUom: "pcs Buk Caramel Popcorn", status: "AKTIF", lokasi: "GUDANG", barcode: "[IF21300003]Buk Caramel Popcorn", nptId: "NPT-IF001" },
    { namaItem: "[IB11600002]Air Galon", displayName: "Air Galon", uom: "gln", altUom: "gln Air Galon", status: "AKTIF", lokasi: "GUDANG", barcode: "[IB11600002]Air Galon", nptId: "NPT-IB002" },
    { namaItem: "[IM30100001]Tumbler Cafe Gading", displayName: "Tumbler Cafe Gading", uom: "pcs", altUom: "pcs Tumbler", status: "AKTIF", lokasi: "GUDANG", barcode: "[IM30100001]Tumbler Cafe Gading", nptId: "NPT-IM001" },
    { namaItem: "[IO40100005]Paper Cup 12oz", displayName: "Paper Cup 12oz", uom: "pack", altUom: "pack Cup 12oz", status: "AKTIF", lokasi: "GUDANG", barcode: "[IO40100005]Paper Cup 12oz", nptId: "NPT-IO005" },
    { namaItem: "[IF21300004]Sirup Vanilla 750ml", displayName: "Sirup Vanilla 750ml", uom: "btl", altUom: "btl Sirup Vanilla", status: "AKTIF", lokasi: "TRANSIT", barcode: "[IF21300004]Sirup Vanilla 750ml", nptId: "NPT-IF004" }
  ];

  const DEFAULT_RECIPES = [
    { row: 2, namaItem: "[IF21300003]Buk Caramel Popcorn", product: "[F107C10048] Extra Popcorn Caramel (M)", qtyRcv: 35, uom: "gr" },
    { row: 3, namaItem: "[IF21300003]Buk Caramel Popcorn", product: "[F107C10049] Extra Popcorn Caramel (L)", qtyRcv: 60, uom: "gr" },
    { row: 4, namaItem: "[IB11600002]Air Galon", product: "[B201A10001] Americano Ice (R)", qtyRcv: 150, uom: "ml" }
  ];

  const DEFAULT_CONVERT = [
    { row: 2, namaItem: "[IF21300003]Buk Caramel Popcorn", uom: "pcs", convert: 1000, uomConvert: "gr" },
    { row: 3, namaItem: "[IB11600002]Air Galon", uom: "gln", convert: 19000, uomConvert: "ml" },
    { row: 4, namaItem: "[IO40100005]Paper Cup 12oz", uom: "pack", convert: 50, uomConvert: "pcs" }
  ];

  const STORAGE_PREFIX = 'SIGAP_FIREBASE_DATA_';

  function getLocal(key, def) {
    try {
      const v = localStorage.getItem(STORAGE_PREFIX + key);
      return v ? JSON.parse(v) : def;
    } catch(e) {
      return def;
    }
  }

  function setLocal(key, val) {
    try {
      localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(val));
    } catch(e) {}
  }

  // State initialization
  let dbUsers = getLocal('USERS', [DEFAULT_ADMIN]);
  let dbMaster = getLocal('MASTER', DEFAULT_MASTER);
  let dbInbound = getLocal('INBOUND', []);
  let dbOutbound = getLocal('OUTBOUND', []);
  let dbOpname = getLocal('OPNAME', []);
  let dbExpStatus = getLocal('EXP_STATUS', []);
  let dbRecipes = getLocal('RECIPES', DEFAULT_RECIPES);
  let dbConvert = getLocal('CONVERT', DEFAULT_CONVERT);
  let dbImages = getLocal('IMAGES', []);
  let dbSessions = getLocal('SESSIONS', {});

  // --- FIREBASE FIRESTORE REALTIME & OFFLINE ADAPTER ---
  function updateFirebaseUI(text, isConnected) {
    try {
      const elText = document.getElementById('firebase-status-text');
      const elBadge = document.getElementById('firebase-status-badge');
      if (elText) elText.textContent = text;
      if (elBadge) {
        if (isConnected) {
          elBadge.style.background = 'rgba(16, 185, 129, 0.12)';
          elBadge.style.color = '#059669';
          elBadge.style.borderColor = 'rgba(16, 185, 129, 0.25)';
          elBadge.title = 'Terhubung ke Firebase (sigap21) · Cloud Firestore Aktif';
        } else {
          elBadge.style.background = 'rgba(245, 158, 11, 0.12)';
          elBadge.style.color = '#d97706';
          elBadge.style.borderColor = 'rgba(245, 158, 11, 0.25)';
          elBadge.title = 'Penyimpanan Lokal Aktif (Offline / Sinkronisasi Tertunda)';
        }
      }
    } catch(e) {}
  }

  function getFirestoreDb() {
    return window.SIGAP_FIRESTORE || (window.firebase && window.firebase.apps && window.firebase.apps.length ? window.firebase.firestore() : null);
  }

  function syncToFirestore(collectionName, operation, payload) {
    const db = getFirestoreDb();
    if (!db) return;
    try {
      if (operation === 'add') {
        db.collection(collectionName).add({ ...payload, createdAt: Date.now(), updatedAt: Date.now() })
          .catch(e => console.warn(`[SIGAP] Firestore ${collectionName} add note:`, e.message));
      } else if (operation === 'docSet') {
        db.collection(collectionName).doc(payload.docId).set(payload.data, { merge: true })
          .catch(e => console.warn(`[SIGAP] Firestore ${collectionName} docSet note:`, e.message));
      } else if (operation === 'docDelete') {
        db.collection(collectionName).doc(payload.docId).delete()
          .catch(e => console.warn(`[SIGAP] Firestore ${collectionName} docDelete note:`, e.message));
      } else if (operation === 'batchSet' && Array.isArray(payload)) {
        const batch = db.batch();
        payload.forEach(item => {
          const id = item.id || item.key || db.collection(collectionName).doc().id;
          const ref = db.collection(collectionName).doc(id);
          batch.set(ref, { ...item, updatedAt: Date.now() }, { merge: true });
        });
        batch.commit()
          .catch(e => console.warn(`[SIGAP] Firestore ${collectionName} batch note:`, e.message));
      } else if (operation === 'update' && payload.queryField) {
        db.collection(collectionName).where(payload.queryField, '==', payload.queryVal).limit(1).get()
          .then(snap => {
            if (!snap.empty) {
              snap.docs[0].ref.update({ ...payload.data, updatedAt: Date.now() });
            }
          })
          .catch(e => console.warn(`[SIGAP] Firestore ${collectionName} update note:`, e.message));
      } else if (operation === 'delete' && payload.queryField) {
        db.collection(collectionName).where(payload.queryField, '==', payload.queryVal).limit(1).get()
          .then(snap => {
            if (!snap.empty) {
              snap.docs[0].ref.delete();
            }
          })
          .catch(e => console.warn(`[SIGAP] Firestore ${collectionName} delete note:`, e.message));
      }
    } catch(err) {
      console.warn(`[SIGAP] Firestore sync ${collectionName} exception:`, err);
    }
  }

  function initFirestoreSync() {
    const db = getFirestoreDb();
    if (!db) {
      setTimeout(initFirestoreSync, 800);
      return;
    }

    updateFirebaseUI('sigap21 (Sinkron...)', false);

    // 1. Sync Master Items from Firestore
    db.collection('masterItems').get()
      .then(snap => {
        if (!snap.empty) {
          const items = [];
          snap.forEach(doc => items.push({ id: doc.id, ...doc.data() }));
          if (items.length > 0) {
            dbMaster = items;
            setLocal('MASTER', dbMaster);
            console.log(`[SIGAP] Berhasil memuat ${items.length} master items dari Cloud Firestore.`);
          }
        } else {
          console.log('[SIGAP] Firestore masterItems kosong. Menyiapkan master catalog awal...');
          const batch = db.batch();
          DEFAULT_MASTER.forEach(m => {
            const docRef = db.collection('masterItems').doc();
            batch.set(docRef, { ...m, createdAt: Date.now(), updatedAt: Date.now() });
          });
          batch.commit().catch(e => console.warn('[SIGAP] Initial seed note:', e.message));
        }
        updateFirebaseUI('sigap21 · Aktif', true);
      })
      .catch(err => {
        console.warn('[SIGAP] Firestore connect note:', err.message);
        updateFirebaseUI('sigap21 · Offline', false);
      });

    // 2. Sync Inbound (terbaru)
    db.collection('inbound').limit(500).get()
      .then(snap => {
        if (!snap.empty) {
          const list = [];
          snap.forEach(doc => list.push({ id: doc.id, ...doc.data() }));
          if (list.length > 0) {
            dbInbound = list;
            setLocal('INBOUND', dbInbound);
          }
        }
      }).catch(e => {});

    // 3. Sync Outbound (terbaru)
    db.collection('outbound').limit(500).get()
      .then(snap => {
        if (!snap.empty) {
          const list = [];
          snap.forEach(doc => list.push({ id: doc.id, ...doc.data() }));
          if (list.length > 0) {
            dbOutbound = list;
            setLocal('OUTBOUND', dbOutbound);
          }
        }
      }).catch(e => {});

    // 4. Sync Opname
    db.collection('stockOpname').limit(200).get()
      .then(snap => {
        if (!snap.empty) {
          const list = [];
          snap.forEach(doc => list.push({ id: doc.id, ...doc.data() }));
          if (list.length > 0) {
            dbOpname = list;
            setLocal('OPNAME', dbOpname);
          }
        }
      }).catch(e => {});

    // 5. Sync Users
    db.collection('users').get()
      .then(snap => {
        if (!snap.empty) {
          const list = [];
          snap.forEach(doc => list.push({ id: doc.id, ...doc.data() }));
          if (list.length > 0) {
            dbUsers = list;
            setLocal('USERS', dbUsers);
          }
        } else {
          db.collection('users').doc('admin').set({
            ...DEFAULT_ADMIN,
            createdAt: Date.now(),
            updatedAt: Date.now()
          }).catch(e => {});
        }
      }).catch(e => {});
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', initFirestoreSync);
    } else {
      setTimeout(initFirestoreSync, 300);
    }
  }

  // Date utilities
  function safeParseDateMs(val) {
    if (!val || val === "") return 0;
    try {
      if (val instanceof Date) {
        const ms = new Date(val).setHours(0, 0, 0, 0);
        return isNaN(ms) ? 0 : ms;
      }
      const d = new Date(val);
      const ms = d.setHours(0, 0, 0, 0);
      return isNaN(ms) ? 0 : ms;
    } catch(e) { return 0; }
  }

  function safeFormatDate(val, fmt) {
    if (!val || val === "") return '';
    try {
      const d = val instanceof Date ? val : new Date(val);
      if (isNaN(d.getTime())) return val.toString();
      const dd = String(d.getDate()).padStart(2, '0');
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const yyyy = d.getFullYear();
      const hh = String(d.getHours()).padStart(2, '0');
      const min = String(d.getMinutes()).padStart(2, '0');
      if (fmt === "dd/MM/yyyy") return `${dd}/${mm}/${yyyy}`;
      if (fmt === "yyyy-MM-dd") return `${yyyy}-${mm}-${dd}`;
      if (fmt === "dd/MM/yyyy HH:mm") return `${dd}/${mm}/${yyyy} ${hh}:${min}`;
      const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
      if (fmt === "yyyy MMMM dd") return `${yyyy} ${months[d.getMonth()]} ${dd}`;
      return `${dd}/${mm}/${yyyy}`;
    } catch(e) { return val.toString(); }
  }

  function parseExpDate(val) {
    if (!val || val === "") return "";
    try {
      if (val instanceof Date) return safeFormatDate(val, "yyyy-MM-dd");
      const str = val.toString().trim();
      if (!str) return "";
      const d = new Date(str);
      if (!isNaN(d.getTime())) return safeFormatDate(d, "yyyy-MM-dd");
      return str;
    } catch(e) { return ""; }
  }

  function getKategoriFromNama(namaItem) {
    if (!namaItem) return "LAINNYA";
    const upper = namaItem.toString().toUpperCase().trim();
    if (upper.startsWith("[IF")) return "MAKANAN";
    if (upper.startsWith("[IB")) return "MINUMAN";
    if (upper.startsWith("[IM")) return "MERCHANDISE";
    if (upper.startsWith("[IO")) return "PACKAGING";
    return "LAINNYA";
  }

  function stripCode(name) {
    if (!name) return '';
    return name.toString().replace(/^\[[^\]]*\]\s*/, '').trim();
  }

  function normalizeUserRole(role) {
    const r = (role || '').toString().trim().toUpperCase().replace(/[_-]+/g, ' ').replace(/\s+/g, ' ');
    if (r === 'ADMIN' || r === 'ADMINISTRATOR') return 'ADMIN';
    if (r === 'MANAGER' || r === 'MANAJER') return 'MANAGER';
    return 'STOCK KEEPER';
  }

  function round4(n) {
    return Math.round((n + Number.EPSILON) * 10000) / 10000;
  }

  function toNumberSafe(v) {
    if (typeof v === 'number') return isNaN(v) ? 0 : v;
    if (v === null || v === undefined) return 0;
    let t = v.toString().trim().replace(/[^0-9,.\-]/g, '');
    if (t.indexOf(',') > -1 && t.indexOf('.') > -1) {
      t = (t.lastIndexOf(',') > t.lastIndexOf('.')) ? t.replace(/\./g, '').replace(',', '.') : t.replace(/,/g, '');
    } else if (t.indexOf(',') > -1) {
      t = t.replace(',', '.');
    }
    const n = parseFloat(t);
    return isNaN(n) ? 0 : n;
  }

  function normItemKey(v) {
    if (v === null || v === undefined) return '';
    return v.toString().replace(/\s+/g, ' ').trim().toUpperCase();
  }

  function itemKeyVariants(nama) {
    const full = normItemKey(nama);
    const clean = normItemKey(stripCode(nama || ''));
    return clean && clean !== full ? [full, clean] : [full];
  }

  function lookupByItem(map, nama) {
    const keys = itemKeyVariants(nama);
    for (const k of keys) {
      if (map.has(k)) return map.get(k);
    }
    return null;
  }

  // Session & Auth
  function checkSessionInternal(token) {
    if (!token) return { success: false, sessionInvalid: true, message: "Token kosong." };
    const user = dbSessions[token];
    if (!user) return { success: false, sessionInvalid: true, message: "Sesi kedaluwarsa. Silakan login ulang." };
    const current = dbUsers.find(u => u.username.toLowerCase() === user.username.toLowerCase());
    if (!current || (current.status !== 'AKTIF' && current.status !== 'AKTIV')) {
      delete dbSessions[token];
      setLocal('SESSIONS', dbSessions);
      return { success: false, sessionInvalid: true, message: "Akun ini berstatus NONAKTIF. Hubungi admin." };
    }
    current.role = normalizeUserRole(current.role);
    return { success: true, user: current };
  }

  function requireRole(token, allowedRoles) {
    const sess = checkSessionInternal(token);
    if (!sess.success) return { success: false, message: sess.message, unauthorized: true };
    const role = sess.user.role;
    const list = (allowedRoles && allowedRoles.length) ? allowedRoles : ['ADMIN', 'MANAGER'];
    if (list.indexOf(role) === -1) {
      return {
        success: false,
        unauthorized: true,
        message: "Akses ditolak. Fitur ini hanya untuk " + list.join(' / ') + "."
      };
    }
    return { success: true, user: sess.user };
  }

  // FIFO computation identical to Code.gs fifoSisaByKey_
  function computeFifoSisaByKey(dataIn, dataOut) {
    let batchesByItem = {};
    for (let i = 0; i < dataIn.length; i++) {
      const nm = dataIn[i].namaItem ? dataIn[i].namaItem.trim() : "";
      if (!nm) continue;
      const ms = dataIn[i].rawDate || safeParseDateMs(dataIn[i].tanggal);
      if (!batchesByItem[nm]) batchesByItem[nm] = [];
      batchesByItem[nm].push({
        key: dataIn[i].key || dataIn[i].id || ('IN-' + i),
        ms: ms || 0,
        qty: parseFloat(dataIn[i].qty) || 0
      });
    }

    let outByItem = {};
    for (let i = 0; i < dataOut.length; i++) {
      const nm = dataOut[i].namaItem ? dataOut[i].namaItem.trim() : "";
      if (!nm) continue;
      outByItem[nm] = (outByItem[nm] || 0) + (parseFloat(dataOut[i].qty) || 0);
    }

    let sisaByKey = {};
    Object.keys(batchesByItem).forEach(nm => {
      const batches = batchesByItem[nm].sort((a, b) => a.ms - b.ms);
      let remainingOut = outByItem[nm] || 0;
      for (const b of batches) {
        const consumed = Math.min(b.qty, remainingOut);
        remainingOut -= consumed;
        sisaByKey[b.key] = Math.round((b.qty - consumed) * 100) / 100;
      }
    });
    return sisaByKey;
  }

  // Generator No SPB identical to Code.gs
  function nextNoSpb(dateObj) {
    const ddmmyy = safeFormatDate(dateObj, "dd/MM/yyyy").replace(/\//g, '').slice(0, 4) + String(dateObj.getFullYear()).slice(-2);
    const spbPrefix = "SPB-" + ddmmyy + "-";
    let urut = 1;
    for (let i = dbOutbound.length - 1; i >= 0; i--) {
      const val = (dbOutbound[i].noSpb || "").toString().trim().toUpperCase();
      if (val.startsWith(spbPrefix)) {
        const num = parseInt(val.replace(spbPrefix, ""), 10);
        if (!isNaN(num)) {
          urut = Math.max(urut, num + 1);
        }
      }
    }
    return spbPrefix + ("00" + urut).slice(-3);
  }

  // --- API IMPLEMENTATION ---
  const SIGAPApi = {
    // 1. Auth
    loginUser(payload, maybePassword) {
      let username = '';
      let password = '';

      if (typeof payload === 'string') {
        username = payload;
        password = typeof maybePassword === 'string' ? maybePassword : '';
      } else if (payload && typeof payload === 'object') {
        username = payload.username || payload.user || '';
        password = payload.password || payload.pass || '';
      }

      username = (username || '').toString().trim();
      password = (password || '').toString().trim();

      if (!username || !password) {
        return Promise.resolve({ success: false, message: "Username dan password wajib diisi." });
      }

      // Ensure default admin exists if user database was cleared or empty
      if (!Array.isArray(dbUsers) || dbUsers.length === 0) {
        dbUsers = [DEFAULT_ADMIN];
        setLocal('USERS', dbUsers);
      }

      const uname = username.toLowerCase();
      let user = dbUsers.find(u => u.username && u.username.toLowerCase() === uname);

      // Fallback for default demo admin if not in dbUsers
      if (!user && (uname === 'admin' || uname === 'administrator')) {
        user = { ...DEFAULT_ADMIN };
        dbUsers.push(user);
        setLocal('USERS', dbUsers);
      }

      if (!user) {
        return Promise.resolve({ success: false, message: "Username tidak ditemukan." });
      }

      if (user.status !== 'AKTIF' && user.status !== 'AKTIV') {
        return Promise.resolve({ success: false, message: "Akun ini berstatus NONAKTIF. Hubungi admin." });
      }

      // Demo authentication: accepts matching password, password hash or standard demo admin123
      const token = 'token_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
      user.role = normalizeUserRole(user.role);
      dbSessions[token] = user;
      setLocal('SESSIONS', dbSessions);
      setLocal('CURRENT_TOKEN', token);
      return Promise.resolve({ success: true, token, user });
    },

    checkSession(token) {
      const activeToken = token || getLocal('CURRENT_TOKEN', null);
      const res = checkSessionInternal(activeToken);
      if (res && res.success) {
        return Promise.resolve({ active: true, user: res.user, token: activeToken });
      }
      return Promise.resolve({ active: false, message: res.message });
    },

    logoutUser(token) {
      const activeToken = token || getLocal('CURRENT_TOKEN', null);
      if (activeToken && dbSessions[activeToken]) {
        delete dbSessions[activeToken];
        setLocal('SESSIONS', dbSessions);
      }
      try { localStorage.removeItem(STORAGE_PREFIX + 'CURRENT_TOKEN'); } catch(e) {}
      return Promise.resolve({ success: true });
    },

    listUsers(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN']);
      if (!auth.success) return Promise.resolve(auth);
      const list = dbUsers.map((u, i) => ({
        rowIndex: i + 2,
        username: u.username,
        nama: u.nama || u.username,
        role: normalizeUserRole(u.role),
        roleAsli: u.role,
        status: (u.status === 'AKTIF' || u.status === 'AKTIV') ? 'AKTIF' : 'NONAKTIF',
        updatedAt: u.updatedAt || 'Baru saja',
        updatedBy: u.updatedBy || ''
      }));
      return Promise.resolve({ success: true, data: list, currentUser: auth.user.username });
    },

    saveUser(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN']);
      if (!auth.success) return Promise.resolve(auth);
      if (!payload.username || !payload.username.trim()) {
        return Promise.resolve({ success: false, message: "Username wajib diisi." });
      }
      const uname = payload.username.trim().toLowerCase();
      const role = normalizeUserRole(payload.role);
      const status = (payload.status || 'AKTIF').toUpperCase() === 'NONAKTIF' ? 'NONAKTIF' : 'AKTIF';
      const nama = payload.nama ? payload.nama.trim() : uname;

      const idx = dbUsers.findIndex(u => u.username.toLowerCase() === uname);
      const now = safeFormatDate(new Date(), "dd/MM/yyyy HH:mm");
      const by = auth.user.username;

      if (idx >= 0) {
        // Proteksi admin terakhir
        const wasAdmin = normalizeUserRole(dbUsers[idx].role) === 'ADMIN';
        const wasActive = dbUsers[idx].status === 'AKTIF';
        const stillAdmin = role === 'ADMIN' && status === 'AKTIF';
        const activeAdmins = dbUsers.filter((u, i) => i !== idx && normalizeUserRole(u.role) === 'ADMIN' && u.status === 'AKTIF').length;
        if (wasAdmin && wasActive && !stillAdmin && activeAdmins === 0) {
          return Promise.resolve({
            success: false,
            message: "Tidak dapat melanjutkan: ini administrator aktif terakhir. Buat / aktifkan admin lain terlebih dahulu."
          });
        }
        dbUsers[idx].nama = nama;
        dbUsers[idx].role = role;
        dbUsers[idx].status = status;
        dbUsers[idx].updatedAt = now;
        dbUsers[idx].updatedBy = by;
        setLocal('USERS', dbUsers);
        syncToFirestore('users', 'docSet', { docId: uname, data: { username: uname, nama, role, status, updatedAt: now, updatedBy: by } });
        return Promise.resolve({ success: true, message: `User '${uname}' berhasil diperbarui.` });
      } else {
        const udata = { username: uname, nama, role, status, updatedAt: now, updatedBy: by };
        dbUsers.push(udata);
        setLocal('USERS', dbUsers);
        syncToFirestore('users', 'docSet', { docId: uname, data: udata });
        return Promise.resolve({ success: true, message: `User '${uname}' berhasil ditambahkan.` });
      }
    },

    deleteUser(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN']);
      if (!auth.success) return Promise.resolve(auth);
      const uname = (payload.username || '').toLowerCase().trim();
      if (uname === auth.user.username.toLowerCase()) {
        return Promise.resolve({ success: false, message: "Anda tidak dapat menghapus akun Anda sendiri." });
      }
      const idx = dbUsers.findIndex(u => u.username.toLowerCase() === uname);
      if (idx === -1) return Promise.resolve({ success: false, message: "User tidak ditemukan." });

      const isAdmin = normalizeUserRole(dbUsers[idx].role) === 'ADMIN';
      const activeAdmins = dbUsers.filter((u, i) => i !== idx && normalizeUserRole(u.role) === 'ADMIN' && u.status === 'AKTIF').length;
      if (isAdmin && activeAdmins === 0) {
        return Promise.resolve({
          success: false,
          message: "Tidak dapat menghapus administrator aktif terakhir. Sistem harus selalu memiliki minimal satu ADMIN aktif."
        });
      }
      dbUsers.splice(idx, 1);
      setLocal('USERS', dbUsers);
      syncToFirestore('users', 'docDelete', { docId: uname });
      return Promise.resolve({ success: true, message: `User '${payload.username}' dihapus.` });
    },

    // 2. Master Items
    getMasterData() {
      const items = dbMaster
        .filter(it => it.status === 'AKTIF' || it.status === 'AKTIV')
        .map(it => ({
          namaItem: it.namaItem,
          displayName: it.displayName || stripCode(it.namaItem),
          uom: it.uom || '',
          altUom: it.altUom || '',
          status: it.status,
          barcode: it.barcode || it.namaItem,
          nptId: it.nptId || '',
          lokasi: it.lokasi || 'GUDANG'
        }));
      return Promise.resolve({ success: true, data: items });
    },

    getAllMasterItems(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      const items = dbMaster.map((it, i) => ({
        rowIndex: i + 2,
        namaItem: it.namaItem,
        displayName: it.displayName || stripCode(it.namaItem),
        uom: it.uom || '',
        namaPlusUom: it.namaPlusUom || (it.namaItem + (it.uom || '')),
        altUom: it.altUom || '',
        status: it.status || 'AKTIF',
        nptId: it.nptId || '',
        lokasi: (it.lokasi || 'GUDANG').toUpperCase()
      }));
      return Promise.resolve({ success: true, data: items });
    },

    getMasterStats() {
      let total = 0, aktif = 0, nonaktif = 0;
      dbMaster.forEach(it => {
        if (!it.namaItem) return;
        total++;
        if (it.status === 'AKTIF' || it.status === 'AKTIV') aktif++;
        else nonaktif++;
      });
      return Promise.resolve({ success: true, data: { total, aktif, nonaktif } });
    },

    addMasterItem(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      const nama = payload.namaItem.trim();
      if (dbMaster.some(it => it.namaItem.toUpperCase() === nama.toUpperCase())) {
        return Promise.resolve({ success: false, message: `Item '${nama}' sudah ada di Master!` });
      }
      const newItem = {
        namaItem: nama,
        displayName: stripCode(nama),
        uom: payload.uom ? payload.uom.trim() : '',
        altUom: payload.altUom ? payload.altUom.trim() : '',
        status: payload.status ? payload.status.trim().toUpperCase() : 'AKTIF',
        lokasi: payload.lokasi ? payload.lokasi.trim().toUpperCase() : 'GUDANG',
        barcode: nama,
        nptId: payload.nptId || ''
      };
      dbMaster.push(newItem);
      setLocal('MASTER', dbMaster);
      syncToFirestore('masterItems', 'add', newItem);
      return Promise.resolve({ success: true, message: "Item berhasil ditambahkan!" });
    },

    updateMasterItem(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      const originalNama = (payload.originalNamaItem || payload.namaItem || '').trim().toUpperCase();
      const idx = dbMaster.findIndex(it => it.namaItem.trim().toUpperCase() === originalNama);
      if (idx === -1) {
        return Promise.resolve({ success: false, message: "Item tidak ditemukan di Master." });
      }
      const namaNew = payload.namaItem.trim();
      dbMaster[idx].namaItem = namaNew;
      dbMaster[idx].displayName = stripCode(namaNew);
      dbMaster[idx].uom = payload.uom ? payload.uom.trim() : '';
      dbMaster[idx].altUom = payload.altUom ? payload.altUom.trim() : '';
      dbMaster[idx].status = payload.status ? payload.status.trim().toUpperCase() : 'AKTIF';
      dbMaster[idx].lokasi = payload.lokasi ? payload.lokasi.trim().toUpperCase() : 'GUDANG';
      setLocal('MASTER', dbMaster);
      syncToFirestore('masterItems', 'update', { queryField: 'namaItem', queryVal: originalNama, data: dbMaster[idx] });
      return Promise.resolve({ success: true, message: `Item '${stripCode(namaNew)}' berhasil diperbarui!` });
    },

    deleteMasterItem(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      const target = (payload.namaItem || '').trim().toUpperCase();
      const idx = dbMaster.findIndex(it => it.namaItem.trim().toUpperCase() === target);
      if (idx === -1) return Promise.resolve({ success: false, message: "Item tidak ditemukan untuk dihapus." });
      dbMaster.splice(idx, 1);
      setLocal('MASTER', dbMaster);
      syncToFirestore('masterItems', 'delete', { queryField: 'namaItem', queryVal: target });
      return Promise.resolve({ success: true, message: "Item berhasil dihapus dari Master!" });
    },

    // 3. Inbound
    getInboundData() {
      const list = dbInbound.slice().reverse().map((row, i) => ({
        id: row.id || ('IN-' + i),
        rawDate: row.rawDate,
        tanggalGroup: row.tanggalGroup || safeFormatDate(new Date(row.rawDate), "yyyy MMMM dd"),
        tanggal: row.tanggal,
        tanggalEdit: row.tanggalEdit,
        noDo: row.noDo || '',
        namaItem: row.namaItem,
        qty: parseFloat(row.qty) || 0,
        uom: row.uom || '',
        altUom: row.altUom || '',
        expDate: parseExpDate(row.expDate),
        noPgr: row.noPgr || '',
        batch: row.batch || ''
      }));
      return Promise.resolve({ success: true, data: list });
    },

    saveInboundData(payload) {
      if (!payload || !payload.tanggal) return Promise.resolve({ success: false, message: "Tanggal wajib diisi." });
      if (!payload.noDo || !payload.noDo.trim()) return Promise.resolve({ success: false, message: "Nomor DO wajib diisi." });
      if (!payload.items || !payload.items.length) return Promise.resolve({ success: false, message: "Tidak ada item untuk disimpan." });

      const dateObj = new Date(payload.tanggal);
      const dateMs = new Date(payload.tanggal).setHours(0, 0, 0, 0);
      const noDo = payload.noDo.trim();

      // Signature anti duplicate: ms | item | qty
      const sig = {};
      dbInbound.forEach(r => {
        const k = `${r.rawDate}|${r.namaItem.toUpperCase()}|${parseFloat(r.qty).toFixed(2)}`;
        sig[k] = true;
      });

      const now = new Date();
      const stamp = now.getTime().toString().slice(-6);
      const base = "MSK-" + safeFormatDate(now, "yyyy-MM-dd").replace(/-/g, '') + "-" + stamp;

      const lokasiMap = {};
      dbMaster.forEach(m => { lokasiMap[m.namaItem] = m.lokasi || 'GUDANG'; });

      let savedRows = [];
      let skipped = 0;

      payload.items.forEach((it, i) => {
        const nm = it.namaItem ? it.namaItem.trim() : '';
        if (!nm) return;
        const qty = parseFloat(it.qty) || 0;
        const sigKey = `${dateMs}|${nm.toUpperCase()}|${qty.toFixed(2)}`;
        if (sig[sigKey]) {
          skipped++;
          return;
        }
        sig[sigKey] = true;
        const rowId = `${base}-${i + 1}`;
        const uom = it.uom ? it.uom.trim() : '';
        const altUom = it.altUom ? it.altUom.trim() : '';
        const expDate = it.expDate ? it.expDate.trim() : '';
        const batch = it.batch ? it.batch.trim() : '';
        const ket = lokasiMap[nm] || 'GUDANG';

        const row = {
          id: rowId,
          key: rowId,
          rawDate: dateMs,
          tanggal: safeFormatDate(dateObj, "dd/MM/yyyy"),
          tanggalEdit: payload.tanggal,
          tanggalGroup: safeFormatDate(dateObj, "yyyy MMMM dd"),
          noDo: noDo,
          namaItem: nm,
          qty: qty,
          uom: uom,
          altUom: altUom,
          expDate: expDate,
          noPgr: it.noPgr || '',
          keterangan: ket,
          batch: batch
        };
        dbInbound.push(row);
        savedRows.push(row);
      });

      setLocal('INBOUND', dbInbound);
      if (savedRows.length > 0) {
        syncToFirestore('inbound', 'batchSet', savedRows);
      }
      return Promise.resolve({
        success: true,
        saved: savedRows,
        skipped,
        message: `${savedRows.length} item tersimpan (DO: ${noDo})${skipped ? ` · ${skipped} dilewati (duplikat tanggal+item+qty).` : '.'}`
      });
    },

    updateInboundData(payload) {
      const idx = dbInbound.findIndex(r => r.id === payload.id);
      if (idx === -1) return Promise.resolve({ success: false, message: "ID tidak ditemukan." });
      const d = new Date(payload.tanggal);
      dbInbound[idx].rawDate = safeParseDateMs(d);
      dbInbound[idx].tanggal = safeFormatDate(d, "dd/MM/yyyy");
      dbInbound[idx].tanggalEdit = payload.tanggal;
      dbInbound[idx].tanggalGroup = safeFormatDate(d, "yyyy MMMM dd");
      dbInbound[idx].noDo = payload.noDo || '';
      dbInbound[idx].qty = parseFloat(payload.qty);
      dbInbound[idx].altUom = payload.altUom || '';
      dbInbound[idx].expDate = payload.expDate || '';
      setLocal('INBOUND', dbInbound);
      syncToFirestore('inbound', 'docSet', { docId: payload.id, data: dbInbound[idx] });
      return Promise.resolve({ success: true, message: "Data Masuk berhasil diubah." });
    },

    deleteInboundData(payload) {
      const idx = dbInbound.findIndex(r => r.id === payload.id);
      if (idx === -1) return Promise.resolve({ success: false, message: "ID tidak ditemukan." });
      const delId = dbInbound[idx].id;
      dbInbound.splice(idx, 1);
      setLocal('INBOUND', dbInbound);
      syncToFirestore('inbound', 'docDelete', { docId: delId });
      return Promise.resolve({ success: true, message: "Data masuk dihapus." });
    },

    autoFillInKeterangan() {
      let filled = 0;
      const lokasiMap = {};
      dbMaster.forEach(m => { lokasiMap[m.namaItem] = m.lokasi || 'GUDANG'; });
      dbInbound.forEach(r => {
        if (!r.keterangan && lokasiMap[r.namaItem]) {
          r.keterangan = lokasiMap[r.namaItem];
          filled++;
        }
      });
      setLocal('INBOUND', dbInbound);
      return Promise.resolve({ success: true, filled, message: `Auto-isi KET selesai: ${filled} baris terisi otomatis.` });
    },

    syncTransitToOut(payload) {
      const startMs = payload && payload.startDate ? new Date(payload.startDate).setHours(0, 0, 0, 0) : 0;
      const endMs = payload && payload.endDate ? new Date(payload.endDate).setHours(23, 59, 59, 999) : Infinity;

      const sig = {};
      dbOutbound.forEach(o => {
        sig[`${o.rawDate}|${o.namaItem.toUpperCase()}|${parseFloat(o.qty).toFixed(2)}`] = true;
      });

      let added = 0, skipped = 0;
      dbInbound.forEach(r => {
        if ((r.keterangan || '').toUpperCase() !== 'TRANSIT') return;
        if (r.rawDate < startMs || r.rawDate > endMs) return;
        const q = parseFloat(r.qty) || 0;
        const sigKey = `${r.rawDate}|${r.namaItem.toUpperCase()}|${q.toFixed(2)}`;
        if (sig[sigKey]) {
          skipped++;
          return;
        }
        sig[sigKey] = true;
        const d = new Date(r.rawDate);
        const trxId = "TRS-" + Math.random().toString(36).substring(2, 10).toUpperCase();
        dbOutbound.push({
          id: trxId,
          key: trxId,
          rawDate: r.rawDate,
          tanggal: safeFormatDate(d, "dd/MM/yyyy"),
          tanggalEdit: safeFormatDate(d, "yyyy-MM-dd"),
          tanggalGroup: safeFormatDate(d, "yyyy MMMM dd"),
          noSpb: r.noDo || '',
          namaItem: r.namaItem,
          qty: q,
          thn: String(d.getFullYear()),
          bln: String(d.getMonth() + 1).padStart(2, '0'),
          tgl: String(d.getDate()).padStart(2, '0'),
          kategori: getKategoriFromNama(r.namaItem),
          status: "TRANSIT"
        });
        added++;
      });
      setLocal('OUTBOUND', dbOutbound);
      return Promise.resolve({
        success: true,
        added,
        skipped,
        message: `Sync Transit selesai: ${added} baris baru dilempar ke OUT, ${skipped} dilewati (duplikat).`
      });
    },

    // 4. Outbound
    peekNextNoSpb(payload) {
      const d = payload && payload.tanggal ? new Date(payload.tanggal) : new Date();
      return Promise.resolve({ success: true, noSpb: nextNoSpb(d) });
    },

    saveOutboundData(payload) {
      if (!payload || !payload.tanggal) return Promise.resolve({ success: false, message: "Tanggal wajib diisi." });
      if (!payload.items || !payload.items.length) return Promise.resolve({ success: false, message: "Item wajib diisi." });

      const dateObj = new Date(payload.tanggal);
      const dateMs = new Date(payload.tanggal).setHours(0, 0, 0, 0);
      const now = new Date();
      const stamp = now.getTime().toString().slice(-6);
      const trxId = "OUT-" + safeFormatDate(now, "yyyy-MM-dd").replace(/-/g, '') + "-" + stamp;
      const noSpb = nextNoSpb(dateObj);

      const savedRows = [];
      payload.items.forEach((it, i) => {
        if (!it.namaItem || !it.namaItem.trim()) return;
        const rowId = payload.items.length > 1 ? `${trxId}-${i + 1}` : trxId;
        const qty = parseFloat(it.qty) || 0;
        const kat = it.kategori || getKategoriFromNama(it.namaItem);
        const ket = it.keterangan ? it.keterangan.trim() : '';

        const row = {
          id: rowId,
          key: rowId,
          rawDate: dateMs,
          tanggal: safeFormatDate(dateObj, "dd/MM/yyyy"),
          tanggalEdit: payload.tanggal,
          tanggalGroup: safeFormatDate(dateObj, "yyyy MMMM dd"),
          noSpb: noSpb,
          namaItem: it.namaItem,
          qty: qty,
          thn: String(dateObj.getFullYear()),
          bln: String(dateObj.getMonth() + 1).padStart(2, '0'),
          tgl: String(dateObj.getDate()).padStart(2, '0'),
          kategori: kat,
          status: "KELUAR",
          keterangan: ket
        };
        dbOutbound.push(row);
        savedRows.push(row);
      });

      setLocal('OUTBOUND', dbOutbound);
      if (savedRows.length > 0) {
        syncToFirestore('outbound', 'batchSet', savedRows);
      }
      return Promise.resolve({ success: true, saved: savedRows, message: `Data berhasil disimpan (SPB: ${noSpb})!` });
    },

    getOutboundData() {
      const list = dbOutbound.slice().reverse().map((row, i) => ({
        id: row.id || ('OUT-' + i),
        rawDate: row.rawDate,
        tanggalEdit: row.tanggalEdit,
        tanggalGroup: row.tanggalGroup || safeFormatDate(new Date(row.rawDate), "yyyy MMMM dd"),
        tanggal: row.tanggal,
        noSpb: row.noSpb || '',
        namaItem: row.namaItem,
        qty: parseFloat(row.qty) || 0,
        altUom: row.noSpb || '',
        uom: '',
        kategori: row.kategori || getKategoriFromNama(row.namaItem),
        status: row.status || '',
        keterangan: row.keterangan || ''
      }));
      return Promise.resolve({ success: true, data: list });
    },

    updateOutboundData(payload) {
      const idx = dbOutbound.findIndex(r => r.id === payload.id);
      if (idx === -1) return Promise.resolve({ success: false, message: "ID tidak ditemukan." });
      const d = new Date(payload.tanggal);
      dbOutbound[idx].rawDate = safeParseDateMs(d);
      dbOutbound[idx].tanggal = safeFormatDate(d, "dd/MM/yyyy");
      dbOutbound[idx].tanggalEdit = payload.tanggal;
      dbOutbound[idx].tanggalGroup = safeFormatDate(d, "yyyy MMMM dd");
      dbOutbound[idx].qty = parseFloat(payload.qty);
      setLocal('OUTBOUND', dbOutbound);
      syncToFirestore('outbound', 'docSet', { docId: payload.id, data: dbOutbound[idx] });
      return Promise.resolve({ success: true, message: "Data berhasil diubah." });
    },

    deleteOutboundData(payload) {
      const idx = dbOutbound.findIndex(r => r.id === payload.id);
      if (idx === -1) return Promise.resolve({ success: false, message: "ID tidak ditemukan." });
      const delId = dbOutbound[idx].id;
      dbOutbound.splice(idx, 1);
      setLocal('OUTBOUND', dbOutbound);
      syncToFirestore('outbound', 'docDelete', { docId: delId });
      return Promise.resolve({ success: true, message: "Data keluar dihapus." });
    },

    // 5. Stock Card Calculation
    getStockCardData() {
      const stockMap = {};
      const lokasiMap = {};
      dbMaster.forEach(m => { lokasiMap[m.namaItem] = m.lokasi || 'GUDANG'; });

      const now = new Date();
      const currMonthKey = now.getFullYear() * 12 + now.getMonth();
      const fcTotal = {};
      const fcMinMonth = {};

      // Inbound processing
      dbInbound.forEach(row => {
        const nm = row.namaItem ? row.namaItem.trim() : "";
        if (!nm) return;
        const qty = parseFloat(row.qty) || 0;
        const uom = row.uom ? row.uom.trim() : '';
        const noPgr = (row.noPgr || '').trim().toUpperCase();
        const kat = getKategoriFromNama(nm);

        if (!stockMap[nm]) {
          stockMap[nm] = { uom, masuk: 0, keluar: 0, awal: 0, kategori: kat };
        }
        if (!stockMap[nm].uom && uom) stockMap[nm].uom = uom;

        // RULE: NO PGR = "STOCK AWAL" -> awal
        if (noPgr === "STOCK AWAL" || (row.noDo || '').toUpperCase().includes("MIGRASI")) {
          stockMap[nm].awal += qty;
        } else {
          stockMap[nm].masuk += qty;
        }
      });

      // Outbound processing
      dbOutbound.forEach(row => {
        const nm = row.namaItem ? row.namaItem.trim() : "";
        if (!nm) return;
        const qty = parseFloat(row.qty) || 0;
        const kat = getKategoriFromNama(nm);

        if (!stockMap[nm]) {
          stockMap[nm] = { uom: '', masuk: 0, keluar: 0, awal: 0, kategori: kat };
        }
        stockMap[nm].keluar += qty;

        const ms = row.rawDate;
        if (ms) {
          const d = new Date(ms);
          const mKey = d.getFullYear() * 12 + d.getMonth();
          if (mKey < currMonthKey) {
            fcTotal[nm] = (fcTotal[nm] || 0) + qty;
            if (!(nm in fcMinMonth) || mKey < fcMinMonth[nm]) fcMinMonth[nm] = mKey;
          }
        }
      });

      const KATEGORI_ORDER = ["MAKANAN", "MINUMAN", "MERCHANDISE", "PACKAGING", "LAINNYA"];
      const stockList = Object.keys(stockMap).map(nm => {
        const s = stockMap[nm];
        const sisa = s.awal + s.masuk - s.keluar;

        let avgOut = 0;
        if (nm in fcMinMonth) {
          const months = Math.max(1, currMonthKey - fcMinMonth[nm]);
          avgOut = Math.round((fcTotal[nm] || 0) / months);
        }
        const lokasi = lokasiMap[nm] || 'GUDANG';
        const alert = lokasi === 'GUDANG' && avgOut > 0 && sisa < avgOut;

        return {
          namaItem: nm,
          uom: s.uom,
          awal: s.awal.toFixed(2),
          masuk: s.masuk.toFixed(2),
          keluar: s.keluar.toFixed(2),
          sisa: sisa.toFixed(2),
          kategori: s.kategori,
          lokasi: lokasi,
          avgOut: avgOut,
          alert: alert
        };
      });

      stockList.sort((a, b) => {
        const ka = KATEGORI_ORDER.indexOf(a.kategori);
        const kb = KATEGORI_ORDER.indexOf(b.kategori);
        if (ka !== kb) return ka - kb;
        return a.namaItem.localeCompare(b.namaItem);
      });

      return Promise.resolve({ success: true, data: stockList });
    },

    getItemDetailLog(payload) {
      const itemName = payload && payload.itemName;
      const startMs = payload && payload.startDate ? new Date(payload.startDate).setHours(0, 0, 0, 0) : 0;
      const endMs = payload && payload.endDate ? new Date(payload.endDate).setHours(23, 59, 59, 999) : Infinity;

      let logs = [];
      dbInbound.forEach(row => {
        if (row.namaItem !== itemName) return;
        const ms = row.rawDate;
        if (ms < startMs || ms > endMs) return;
        const noPgr = (row.noPgr || '').trim().toUpperCase();
        let jenis = 'IN';
        if (noPgr === "STOCK AWAL" || (row.noDo || '').toUpperCase().includes("MIGRASI")) jenis = 'AWAL';
        else if (noPgr.startsWith("ADJUSTMENT")) jenis = 'ADJ-IN';

        logs.push({
          jenis,
          rawDate: ms,
          id: row.id,
          tanggal: row.tanggal,
          qty: parseFloat(row.qty) || 0,
          uom: row.uom || '',
          expDate: parseExpDate(row.expDate)
        });
      });

      dbOutbound.forEach(row => {
        if (row.namaItem !== itemName) return;
        const ms = row.rawDate;
        if (ms < startMs || ms > endMs) return;
        const status = (row.status || '').trim().toUpperCase();
        logs.push({
          jenis: status === 'ADJUSTMENT' ? 'ADJ-OUT' : 'OUT',
          rawDate: ms,
          id: row.id,
          tanggal: row.tanggal,
          qty: parseFloat(row.qty) || 0,
          uom: ''
        });
      });

      logs.sort((a, b) => a.rawDate - b.rawDate);
      return Promise.resolve({ success: true, data: logs });
    },

    getFifoExpSuggestion(payload) {
      const itemName = payload && payload.itemName ? payload.itemName.trim() : '';
      if (!itemName) return Promise.resolve({ success: false, message: "Nama item wajib diisi." });

      const sisaByKey = computeFifoSisaByKey(dbInbound, dbOutbound);
      let best = null;

      dbInbound.forEach((row, i) => {
        if (row.namaItem !== itemName) return;
        const key = row.key || row.id || ('IN-' + i);
        const sisa = (key in sisaByKey) ? sisaByKey[key] : (parseFloat(row.qty) || 0);
        if (sisa <= 0) return;

        const cand = {
          expDate: parseExpDate(row.expDate),
          sisaBatch: sisa,
          batchNumber: row.batch || '',
          tanggalMasuk: row.tanggal,
          noDo: row.noDo || '',
          _ms: row.rawDate || 0
        };
        if (!best || cand._ms < best._ms) best = cand;
      });

      if (best) delete best._ms;
      return Promise.resolve({ success: true, data: best });
    },

    getScanItemContext(payload) {
      const itemName = payload && payload.itemName ? payload.itemName.trim() : '';
      if (!itemName) return Promise.resolve({ success: false, message: "Nama item wajib diisi." });

      const master = dbMaster.find(m => m.namaItem === itemName);
      return SIGAPApi.getStockCardData().then(stkRes => {
        const stock = stkRes.data.find(s => s.namaItem === itemName);
        const out = {
          namaItem: itemName,
          displayName: stripCode(itemName),
          kategori: (stock && stock.kategori) || getKategoriFromNama(itemName),
          uom: (master && master.uom) || (stock && stock.uom) || '',
          altUom: (master && master.altUom) || '',
          status: (master && master.status) || '',
          nptId: (master && master.nptId) || '',
          lokasi: (master && master.lokasi) || (stock && stock.lokasi) || '',
          sisa: stock ? stock.sisa : null,
          masuk: stock ? stock.masuk : null,
          keluar: stock ? stock.keluar : null,
          awal: stock ? stock.awal : null,
          avgOut: stock ? stock.avgOut : null
        };

        if (payload && payload.withFifo) {
          return SIGAPApi.getFifoExpSuggestion({ itemName }).then(f => {
            out.fifo = f.data || null;
            if (payload.withSpb) {
              return SIGAPApi.peekNextNoSpb({ tanggal: payload.tanggal }).then(p => {
                out.noSpb = p.noSpb || '';
                return { success: true, data: out };
              });
            }
            return { success: true, data: out };
          });
        }
        return { success: true, data: out };
      });
    },

    // 6. Exp Monitor
    getExpMonitorData(payload) {
      const startDate = payload && payload.startDate ? payload.startDate : '';
      const sisaByKey = computeFifoSisaByKey(dbInbound, dbOutbound);

      const statusMap = {};
      dbExpStatus.forEach(st => {
        statusMap[st.key] = {
          status: (st.status || 'AKTIF').toUpperCase(),
          updatedAt: st.updatedAt || '',
          updatedBy: st.updatedBy || ''
        };
      });

      const result = [];
      dbInbound.forEach((row, i) => {
        const nm = row.namaItem ? row.namaItem.trim() : "";
        if (!nm) return;
        const exp = parseExpDate(row.expDate);
        if (!exp) return;
        if (startDate && exp < startDate) return;

        const key = row.key || row.id || ('IN-' + i);
        const ovr = statusMap[key];
        const qty = parseFloat(row.qty) || 0;

        result.push({
          key: key,
          namaItem: nm,
          qty: qty,
          qtySisa: (key in sisaByKey) ? sisaByKey[key] : qty,
          uom: row.uom || '',
          noDo: row.noDo || '',
          tanggal: row.tanggal,
          expDate: exp,
          status: ovr ? ovr.status : 'AKTIF',
          updatedAt: ovr ? ovr.updatedAt : '',
          updatedBy: ovr ? ovr.updatedBy : ''
        });
      });
      return Promise.resolve({ success: true, data: result });
    },

    updateExpStatus(payload) {
      if (!payload || !payload.key) return Promise.resolve({ success: false, message: "Key tidak valid." });
      const status = (payload.status || 'AKTIF').toUpperCase();
      const now = safeFormatDate(new Date(), "dd/MM/yyyy HH:mm");
      const by = payload.user || '';

      const idx = dbExpStatus.findIndex(s => s.key === payload.key);
      if (idx >= 0) {
        dbExpStatus[idx].status = status;
        dbExpStatus[idx].updatedAt = now;
        dbExpStatus[idx].updatedBy = by;
      } else {
        dbExpStatus.push({ key: payload.key, namaItem: payload.namaItem || '', expDate: payload.expDate || '', status, updatedAt: now, updatedBy: by });
      }
      setLocal('EXP_STATUS', dbExpStatus);
      return Promise.resolve({ success: true, message: "Status exp diperbarui: " + status });
    },

    bulkUpdateExpStatus(payload) {
      if (!payload || !payload.items || !payload.items.length) {
        return Promise.resolve({ success: false, message: "Tidak ada item dipilih." });
      }
      const status = (payload.status || 'AKTIF').toUpperCase();
      const now = safeFormatDate(new Date(), "dd/MM/yyyy HH:mm");
      const by = payload.user || '';

      payload.items.forEach(it => {
        if (!it.key) return;
        const idx = dbExpStatus.findIndex(s => s.key === it.key);
        if (idx >= 0) {
          dbExpStatus[idx].status = status;
          dbExpStatus[idx].updatedAt = now;
          dbExpStatus[idx].updatedBy = by;
        } else {
          dbExpStatus.push({ key: it.key, namaItem: it.namaItem || '', expDate: it.expDate || '', status, updatedAt: now, updatedBy: by });
        }
      });
      setLocal('EXP_STATUS', dbExpStatus);
      return Promise.resolve({ success: true, message: `${payload.items.length} item diperbarui -> ${status}` });
    },

    // 7. Stock Opname
    setupOpnameSheet() {
      return Promise.resolve({ success: true, message: "Sheet OPNAME siap digunakan." });
    },

    saveOpnameData(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);

      if (!payload || !payload.tanggal || !payload.periode) {
        return Promise.resolve({ success: false, message: "Tanggal dan Periode opname wajib diisi." });
      }
      if (!payload.items || !payload.items.length) {
        return Promise.resolve({ success: false, message: "Tidak ada item untuk disimpan." });
      }

      const dateObj = new Date(payload.tanggal);
      const periode = payload.periode.trim();
      const now = new Date();
      const stamp = now.getTime().toString().slice(-6);
      const baseId = "OPN-" + safeFormatDate(now, "yyyy-MM-dd").replace(/-/g, '') + "-" + stamp;

      let countPlus = 0, countMinus = 0, countMatch = 0;

      payload.items.forEach((it, i) => {
        const nm = it.namaItem ? it.namaItem.trim() : "";
        if (!nm) return;
        const sistem = parseFloat(it.stockSistem) || 0;
        const fisik = parseFloat(it.stockFisik) || 0;
        const selisih = Math.round((fisik - sistem) * 100) / 100;
        const uom = it.uom ? it.uom.trim() : "";
        const catatan = it.catatan ? it.catatan.trim() : "";
        const key = `${baseId}-${i + 1}`;

        let jenis = "SESUAI";
        let ref = "-";

        if (selisih > 0) {
          jenis = "ADJ MASUK";
          ref = "IN: " + key;
          countPlus++;
          dbInbound.push({
            id: key,
            key: key,
            rawDate: safeParseDateMs(dateObj),
            tanggal: safeFormatDate(dateObj, "dd/MM/yyyy"),
            tanggalEdit: payload.tanggal,
            tanggalGroup: safeFormatDate(dateObj, "yyyy MMMM dd"),
            noDo: "OPNAME " + periode,
            namaItem: nm,
            qty: selisih,
            uom: uom,
            altUom: '',
            expDate: '',
            jenis: 'ADJUSTMENT',
            noPgr: 'ADJUSTMENT OPNAME',
            keterangan: 'GUDANG'
          });
        } else if (selisih < 0) {
          jenis = "ADJ KELUAR";
          ref = "OUT: " + key;
          countMinus++;
          dbOutbound.push({
            id: key,
            key: key,
            rawDate: safeParseDateMs(dateObj),
            tanggal: safeFormatDate(dateObj, "dd/MM/yyyy"),
            tanggalEdit: payload.tanggal,
            tanggalGroup: safeFormatDate(dateObj, "yyyy MMMM dd"),
            noSpb: "OPNAME " + periode,
            namaItem: nm,
            qty: Math.abs(selisih),
            thn: String(dateObj.getFullYear()),
            bln: String(dateObj.getMonth() + 1).padStart(2, '0'),
            tgl: String(dateObj.getDate()).padStart(2, '0'),
            kategori: getKategoriFromNama(nm),
            status: "ADJUSTMENT"
          });
        } else {
          countMatch++;
        }

        dbOpname.push({
          key: key,
          id: key,
          rawDate: safeParseDateMs(dateObj),
          tanggal: safeFormatDate(dateObj, "dd/MM/yyyy"),
          periode: periode,
          namaItem: nm,
          uom: uom,
          sistem: sistem,
          fisik: fisik,
          selisih: selisih,
          jenis: jenis,
          catatan: catatan,
          ref: ref
        });
      });

      setLocal('INBOUND', dbInbound);
      setLocal('OUTBOUND', dbOutbound);
      setLocal('OPNAME', dbOpname);

      syncToFirestore('stockOpname', 'batchSet', payload.items.map((it, i) => ({
        id: `${baseId}-${i + 1}`,
        key: `${baseId}-${i + 1}`,
        rawDate: safeParseDateMs(dateObj),
        tanggal: safeFormatDate(dateObj, "dd/MM/yyyy"),
        periode: periode,
        namaItem: it.namaItem,
        uom: it.uom || '',
        sistem: parseFloat(it.stockSistem) || 0,
        fisik: parseFloat(it.stockFisik) || 0,
        selisih: Math.round(((parseFloat(it.stockFisik) || 0) - (parseFloat(it.stockSistem) || 0)) * 100) / 100
      })));

      return Promise.resolve({
        success: true,
        message: `Opname periode ${periode} tersimpan: ${payload.items.length} item. Adjustment Masuk: ${countPlus} · Adjustment Keluar: ${countMinus} · Sesuai: ${countMatch}.`
      });
    },

    getOpnameReport(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);

      // Build conversion map
      const cvMap = new Map();
      dbConvert.forEach(c => {
        const val = round4(toNumberSafe(c.convert));
        if (val <= 0) return;
        const entry = { faktor: val, uomConvert: c.uomConvert || '', uomAsal: c.uom || '' };
        itemKeyVariants(c.namaItem).forEach(k => {
          if (!cvMap.has(k)) cvMap.set(k, { byUom: new Map(), any: null });
          const slot = cvMap.get(k);
          if (c.uom) slot.byUom.set(normItemKey(c.uom), entry);
          if (!slot.any) slot.any = entry;
        });
      });

      const list = dbOpname.slice().reverse().map(row => {
        const slot = lookupByItem(cvMap, row.namaItem);
        let conv = null;
        if (slot) {
          conv = (row.uom ? slot.byUom.get(normItemKey(row.uom)) : null) || slot.any;
        }
        const faktor = conv ? conv.faktor : 0;
        return {
          key: row.key,
          rawDate: row.rawDate,
          tanggal: row.tanggal,
          periode: row.periode,
          namaItem: row.namaItem,
          uom: row.uom,
          sistem: row.sistem,
          fisik: row.fisik,
          selisih: row.selisih,
          jenis: row.jenis,
          catatan: row.catatan,
          ref: row.ref,
          convertFaktor: faktor,
          uomConvert: conv ? conv.uomConvert : '',
          sistemConvert: faktor ? round4(row.sistem * faktor) : null,
          fisikConvert: faktor ? round4(row.fisik * faktor) : null,
          selisihConvert: faktor ? round4(row.selisih * faktor) : null
        };
      });

      return Promise.resolve({ success: true, data: list });
    },

    updateOpnameReport(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);

      const idx = dbOpname.findIndex(o => o.key === payload.key);
      if (idx === -1) return Promise.resolve({ success: false, message: "Baris opname tidak ditemukan." });

      const row = dbOpname[idx];
      const fisik = parseFloat(payload.fisik) || 0;
      const sistem = parseFloat(row.sistem) || 0;
      const selisih = Math.round((fisik - sistem) * 100) / 100;
      const catatan = payload.catatan ? payload.catatan.trim() : '';

      let jenis = "SESUAI", ref = "-";
      if (selisih > 0) { jenis = "ADJ MASUK"; ref = "IN: " + row.key; }
      else if (selisih < 0) { jenis = "ADJ KELUAR"; ref = "OUT: " + row.key; }

      // Reconcile adjustments
      dbInbound = dbInbound.filter(r => r.id !== row.key);
      dbOutbound = dbOutbound.filter(r => r.id !== row.key);

      const d = new Date(row.rawDate || Date.now());
      if (selisih > 0) {
        dbInbound.push({
          id: row.key, key: row.key, rawDate: row.rawDate, tanggal: row.tanggal,
          tanggalEdit: safeFormatDate(d, "yyyy-MM-dd"), tanggalGroup: safeFormatDate(d, "yyyy MMMM dd"),
          noDo: "OPNAME " + row.periode, namaItem: row.namaItem, qty: selisih, uom: row.uom,
          jenis: "ADJUSTMENT", noPgr: "ADJUSTMENT OPNAME", keterangan: "GUDANG"
        });
      } else if (selisih < 0) {
        dbOutbound.push({
          id: row.key, key: row.key, rawDate: row.rawDate, tanggal: row.tanggal,
          tanggalEdit: safeFormatDate(d, "yyyy-MM-dd"), tanggalGroup: safeFormatDate(d, "yyyy MMMM dd"),
          noSpb: "OPNAME " + row.periode, namaItem: row.namaItem, qty: Math.abs(selisih),
          thn: String(d.getFullYear()), bln: String(d.getMonth() + 1).padStart(2, '0'), tgl: String(d.getDate()).padStart(2, '0'),
          kategori: getKategoriFromNama(row.namaItem), status: "ADJUSTMENT"
        });
      }

      row.fisik = fisik;
      row.selisih = selisih;
      row.jenis = jenis;
      row.catatan = catatan;
      row.ref = ref;

      setLocal('INBOUND', dbInbound);
      setLocal('OUTBOUND', dbOutbound);
      setLocal('OPNAME', dbOpname);

      return Promise.resolve({ success: true, message: `Baris opname '${row.namaItem}' diperbarui.`, selisih, jenis });
    },

    deleteOpnameReport(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);

      const idx = dbOpname.findIndex(o => o.key === payload.key);
      if (idx === -1) return Promise.resolve({ success: false, message: "Baris opname tidak ditemukan." });

      const row = dbOpname[idx];
      dbInbound = dbInbound.filter(r => r.id !== row.key);
      dbOutbound = dbOutbound.filter(r => r.id !== row.key);
      dbOpname.splice(idx, 1);

      setLocal('INBOUND', dbInbound);
      setLocal('OUTBOUND', dbOutbound);
      setLocal('OPNAME', dbOpname);

      return Promise.resolve({ success: true, message: `Baris opname '${row.namaItem}' dihapus.` });
    },

    // 8. Recipe (RCV)
    getRecipeData(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      return Promise.resolve({ success: true, data: dbRecipes });
    },

    addRecipe(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      const nm = (payload.namaItem || '').trim();
      const prod = (payload.product || '').trim();
      const qty = parseFloat(payload.qtyRcv) || 0;
      if (!nm || !prod || qty <= 0) return Promise.resolve({ success: false, message: "Data recipe tidak valid." });

      if (dbRecipes.some(r => r.namaItem.toUpperCase() === nm.toUpperCase() && r.product.toUpperCase() === prod.toUpperCase())) {
        return Promise.resolve({ success: false, message: `Recipe '${nm} -> ${prod}' sudah ada.` });
      }
      const nextRow = dbRecipes.length ? Math.max(...dbRecipes.map(r => r.row)) + 1 : 2;
      dbRecipes.push({ row: nextRow, namaItem: nm, product: prod, qtyRcv: qty, uom: (payload.uom || '').trim() });
      setLocal('RECIPES', dbRecipes);
      return Promise.resolve({ success: true, message: "Recipe berhasil ditambahkan!" });
    },

    updateRecipe(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      const idx = dbRecipes.findIndex(r => r.row === parseInt(payload.row));
      if (idx === -1) return Promise.resolve({ success: false, message: "Baris recipe tidak ditemukan." });
      dbRecipes[idx].namaItem = payload.namaItem.trim();
      dbRecipes[idx].product = payload.product.trim();
      dbRecipes[idx].qtyRcv = parseFloat(payload.qtyRcv);
      dbRecipes[idx].uom = (payload.uom || '').trim();
      setLocal('RECIPES', dbRecipes);
      return Promise.resolve({ success: true, message: "Recipe berhasil diperbarui!" });
    },

    deleteRecipe(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      const idx = dbRecipes.findIndex(r => r.row === parseInt(payload.row));
      if (idx === -1) return Promise.resolve({ success: false, message: "Baris recipe tidak ditemukan." });
      dbRecipes.splice(idx, 1);
      setLocal('RECIPES', dbRecipes);
      return Promise.resolve({ success: true, message: "Recipe berhasil dihapus!" });
    },

    // 9. Convert
    getConvertData(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      return Promise.resolve({ success: true, data: dbConvert });
    },

    addConvert(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      const nm = (payload.namaItem || '').trim();
      const uom = (payload.uom || '').trim();
      const val = parseFloat(payload.convert) || 0;
      if (!nm || !uom || val <= 0) return Promise.resolve({ success: false, message: "Data convert tidak valid." });

      if (dbConvert.some(c => c.namaItem.toUpperCase() === nm.toUpperCase() && c.uom.toUpperCase() === uom.toUpperCase())) {
        return Promise.resolve({ success: false, message: `Konversi '${nm} (${uom})' sudah ada.` });
      }
      const nextRow = dbConvert.length ? Math.max(...dbConvert.map(c => c.row)) + 1 : 2;
      dbConvert.push({ row: nextRow, namaItem: nm, uom, convert: val, uomConvert: (payload.uomConvert || '').trim() });
      setLocal('CONVERT', dbConvert);
      return Promise.resolve({ success: true, message: "Konversi berhasil ditambahkan!" });
    },

    updateConvert(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      const idx = dbConvert.findIndex(c => c.row === parseInt(payload.row));
      if (idx === -1) return Promise.resolve({ success: false, message: "Baris convert tidak ditemukan." });
      dbConvert[idx].namaItem = payload.namaItem.trim();
      dbConvert[idx].uom = payload.uom.trim();
      dbConvert[idx].convert = parseFloat(payload.convert);
      dbConvert[idx].uomConvert = (payload.uomConvert || '').trim();
      setLocal('CONVERT', dbConvert);
      return Promise.resolve({ success: true, message: "Konversi berhasil diperbarui!" });
    },

    deleteConvert(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      const idx = dbConvert.findIndex(c => c.row === parseInt(payload.row));
      if (idx === -1) return Promise.resolve({ success: false, message: "Baris convert tidak ditemukan." });
      dbConvert.splice(idx, 1);
      setLocal('CONVERT', dbConvert);
      return Promise.resolve({ success: true, message: "Konversi berhasil dihapus!" });
    },

    // 10. Item Images
    getItemImages(payload) {
      const active = dbImages.filter(img => img.status === 'ACTIVE');
      return Promise.resolve({ success: true, data: active });
    },

    uploadItemImage(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      if (!payload || !payload.itemKey || !payload.base64) {
        return Promise.resolve({ success: false, message: "Data gambar tidak lengkap." });
      }

      const itemKey = payload.itemKey.trim();
      const mime = (payload.mimeType || 'image/jpeg').toLowerCase();
      const fileName = payload.fileName || 'image.jpg';

      // Archive previous active images for this itemKey
      dbImages.forEach(img => {
        if (img.itemKey.toUpperCase() === itemKey.toUpperCase() && img.status === 'ACTIVE') {
          img.status = 'INACTIVE';
        }
      });

      // Data URL or base64 storage
      const dataUrl = payload.base64.startsWith('data:') ? payload.base64 : `data:${mime};base64,${payload.base64}`;
      const newImg = {
        itemKey: itemKey,
        namaItem: stripCode(itemKey),
        imageUrl: dataUrl,
        fileId: 'img_' + Math.random().toString(36).substring(2, 9),
        fileName: fileName,
        mimeType: mime,
        status: 'ACTIVE',
        updatedAt: safeFormatDate(new Date(), "dd/MM/yyyy HH:mm"),
        updatedBy: auth.user.username
      };
      dbImages.push(newImg);
      setLocal('IMAGES', dbImages);

      return Promise.resolve({
        success: true,
        message: "Foto item berhasil disimpan.",
        itemKey,
        imageUrl: dataUrl,
        fileId: newImg.fileId,
        fileName,
        mimeType: mime
      });
    },

    deleteItemImage(payload) {
      const auth = requireRole(payload && payload.token, ['ADMIN', 'MANAGER']);
      if (!auth.success) return Promise.resolve(auth);
      const target = (payload.itemKey || '').trim().toUpperCase();
      let removed = 0;
      dbImages.forEach(img => {
        if (img.itemKey.toUpperCase() === target && img.status === 'ACTIVE') {
          img.status = 'DELETED';
          removed++;
        }
      });
      setLocal('IMAGES', dbImages);
      if (!removed) return Promise.resolve({ success: false, message: "Tidak ada foto aktif untuk item ini." });
      return Promise.resolve({ success: true, message: "Foto item berhasil dihapus." });
    },

    // 11. Smart EXP Recommendation (1:1 with Code.gs getSmartExpRecommendation)
    getSmartExpRecommendation(payload) {
      const horizon = payload && payload.horizonDays ? parseInt(payload.horizonDays, 10) : 60;
      const sisaByKey = computeFifoSisaByKey(dbInbound, dbOutbound);

      // Outbound history per item
      const outByItem = new Map();
      dbOutbound.forEach(row => {
        const q = parseFloat(row.qty) || 0;
        if (q <= 0) return;
        const k = normItemKey(row.namaItem);
        if (!outByItem.has(k)) outByItem.set(k, []);
        outByItem.get(k).push({ ms: row.rawDate, qty: q });
      });

      // RCV Map
      const rcvMap = new Map();
      dbRecipes.forEach((r, order) => {
        const q = round4(toNumberSafe(r.qtyRcv));
        const entry = { product: r.product, qtyRcv: q, uom: r.uom || '', order, completeness: (q > 0 ? 1 : 0) + (r.uom ? 1 : 0) };
        itemKeyVariants(r.namaItem).forEach(k => {
          if (!rcvMap.has(k)) rcvMap.set(k, { best: null, all: [] });
          const slot = rcvMap.get(k);
          slot.all.push(entry);
          const b = slot.best;
          if (!b || entry.qtyRcv > b.qtyRcv || (entry.qtyRcv === b.qtyRcv && entry.completeness > b.completeness)) {
            slot.best = entry;
          }
        });
      });

      // CONVERT Map
      const cvMap = new Map();
      dbConvert.forEach(r => {
        const val = round4(toNumberSafe(r.convert));
        if (val <= 0) return;
        const uomKey = normItemKey(r.uom);
        const target = r.uomConvert || '';
        itemKeyVariants(r.namaItem).forEach(k => {
          if (!cvMap.has(k)) cvMap.set(k, { byUom: new Map(), any: null, anyUom: '', byUomTarget: new Map(), anyTarget: '' });
          const slot = cvMap.get(k);
          if (uomKey && !slot.byUom.has(uomKey)) { slot.byUom.set(uomKey, val); slot.byUomTarget.set(uomKey, target); }
          if (slot.any === null) { slot.any = val; slot.anyUom = r.uom || ''; slot.anyTarget = target; }
        });
      });

      const statusMap = {};
      dbExpStatus.forEach(st => {
        statusMap[st.key] = (st.status || 'AKTIF').toUpperCase();
      });

      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayMs = today.getTime();
      const rows = [];

      dbInbound.forEach((row, i) => {
        const exp = parseExpDate(row.expDate);
        if (!exp) return;
        const key = row.key || row.id || ('IN-' + i);
        if (statusMap[key] && statusMap[key] !== 'AKTIF') return;

        const qtyIn = parseFloat(row.qty) || 0;
        const sisa = (key in sisaByKey) ? sisaByKey[key] : qtyIn;
        if (sisa <= 0) return;

        const expMs = new Date(exp + 'T00:00:00').getTime();
        const daysRemaining = Math.round((expMs - todayMs) / 86400000);
        if (daysRemaining > horizon) return;

        const rcvSlot = lookupByItem(rcvMap, row.namaItem);
        const best = rcvSlot ? rcvSlot.best : null;

        const cvSlot = lookupByItem(cvMap, row.namaItem);
        let convertValue = 0, convertUom = '', convertedUom = '';
        if (cvSlot) {
          const uk = normItemKey(row.uom);
          if (uk && cvSlot.byUom.has(uk)) {
            convertValue = cvSlot.byUom.get(uk);
            convertUom = row.uom;
            convertedUom = cvSlot.byUomTarget.get(uk) || '';
          } else if (cvSlot.any !== null) {
            convertValue = cvSlot.any;
            convertUom = cvSlot.anyUom || row.uom;
            convertedUom = cvSlot.anyTarget || '';
          }
        }

        const outRow = {
          key: key,
          itemName: row.namaItem,
          displayName: stripCode(row.namaItem),
          kategori: getKategoriFromNama(row.namaItem),
          expDate: exp,
          daysRemaining: daysRemaining,
          remainingQty: round4(sisa),
          remainingUom: row.uom || '',
          qtyIn: round4(qtyIn),
          noDo: row.noDo || '',
          batchNumber: row.batch || '',
          tanggalMasuk: row.tanggal,
          _inMs: row.rawDate || 0,
          selectedProduct: best ? best.product : '',
          productCode: best ? (best.product.match(/^\s*\[([^\]]+)\]/) || [])[1] || '' : '',
          productName: best ? best.product.replace(/^\s*\[[^\]]*\]\s*/, '') : '',
          qtyRcv: best ? best.qtyRcv : 0,
          rcvUom: best ? best.uom : '',
          productChoices: rcvSlot ? rcvSlot.all.length : 0,
          convertValue: convertValue,
          convertUom: convertUom,
          convertedUom: convertedUom,
          convertedQty: 0,
          estimatedProductQty: 0,
          requiredDaily: 0,
          requiredMonthly: 0,
          actualDailyAverage: null,
          actualMonthlyAverage: null,
          salesGapDaily: null,
          historyDays: 0,
          status: 'SAFE',
          statusReason: '',
          recommendation: ''
        };

        if (!best || best.qtyRcv <= 0) {
          outRow.status = 'NO_PRODUCT_MAPPING';
          outRow.recommendation = 'Mapping Product belum tersedia di sheet RCV.';
          rows.push(outRow);
          return;
        }
        if (convertValue <= 0) {
          outRow.status = 'NO_CONVERSION';
          outRow.recommendation = 'Konversi UOM belum tersedia di sheet CONVERT.';
          rows.push(outRow);
          return;
        }

        outRow.convertedQty = round4(sisa * convertValue);
        const estRaw = outRow.convertedQty / best.qtyRcv;
        outRow.estimatedProductQty = Math.floor(estRaw);

        const effDays = Math.max(daysRemaining, 1);
        outRow.requiredDaily = round4(outRow.estimatedProductQty / effDays);
        outRow.requiredMonthly = round4((outRow.estimatedProductQty / effDays) * 30);

        // Historical outbound average
        const outList = outByItem.get(normItemKey(row.namaItem)) || [];
        const WINDOW = 90;
        const fromMs = todayMs - (WINDOW * 86400000);
        let sumOut = 0, earliestMs = null;
        outList.forEach(o => {
          if (o.ms >= fromMs && o.ms <= todayMs + 86400000) {
            sumOut += o.qty;
            if (earliestMs === null || o.ms < earliestMs) earliestMs = o.ms;
          }
        });

        if (sumOut > 0 && earliestMs !== null) {
          let hDays = Math.min(Math.max(Math.round((todayMs - earliestMs) / 86400000) + 1, 1), WINDOW);
          if (hDays >= 7) {
            const productPerDay = (sumOut * convertValue / best.qtyRcv) / hDays;
            outRow.historyDays = hDays;
            outRow.actualDailyAverage = round4(productPerDay);
            outRow.actualMonthlyAverage = round4(productPerDay * 30);
            outRow.salesGapDaily = round4(outRow.requiredDaily - productPerDay);
          }
        }

        // Status assignment
        if (outRow.daysRemaining < 0) {
          outRow.status = 'CRITICAL';
          outRow.statusReason = 'Sudah melewati tanggal expired dan stock masih tersisa.';
          outRow.recommendation = `Stock ${outRow.displayName} sudah melewati expired. Segera lakukan penarikan.`;
        } else if (outRow.estimatedProductQty <= 0) {
          outRow.status = 'WARNING';
          outRow.statusReason = 'Sisa stock belum cukup membentuk satu product utuh.';
          outRow.recommendation = `Sisa stock ${outRow.displayName} belum cukup untuk 1 unit produk.`;
        } else if (outRow.actualDailyAverage === null) {
          outRow.status = outRow.daysRemaining <= 7 ? 'CRITICAL' : (outRow.daysRemaining <= 30 ? 'WARNING' : 'SAFE');
          outRow.statusReason = 'Histori penjualan belum cukup.';
          outRow.recommendation = `Keluarkan minimal ±${Math.ceil(outRow.requiredMonthly)} per bulan.`;
        } else {
          const ratio = outRow.requiredDaily > 0 ? (outRow.actualDailyAverage / outRow.requiredDaily) : 99;
          if (ratio >= 1) {
            outRow.status = 'SAFE';
            outRow.recommendation = `Kecepatan keluar saat ini mencukupi.`;
          } else if (ratio >= 0.6) {
            outRow.status = 'WARNING';
            outRow.recommendation = `Kecepatan penjualan perlu ditingkatkan ±${outRow.salesGapDaily} per hari.`;
          } else {
            outRow.status = 'CRITICAL';
            outRow.recommendation = `Kecepatan keluar jauh di bawah target. Perlu tambahan ±${outRow.salesGapDaily} per hari.`;
          }
        }

        rows.push(outRow);
      });

      // FEFO primary batch tagging
      const seen = {};
      rows.sort((a, b) => {
        if (a.expDate !== b.expDate) return a.expDate < b.expDate ? -1 : 1;
        return a._inMs - b._inMs;
      });
      rows.forEach(r => {
        const k = normItemKey(r.itemName);
        r.isPrimaryBatch = !seen[k];
        seen[k] = (seen[k] || 0) + 1;
      });
      rows.forEach(r => {
        r.batchCountOfItem = seen[normItemKey(r.itemName)];
        delete r._inMs;
      });

      // Priority sort: Critical -> Warning -> Safe
      rows.sort((a, b) => {
        const prio = x => (x.daysRemaining < 0 ? 1 : x.daysRemaining === 0 ? 2 : x.daysRemaining <= 7 ? 3 : x.daysRemaining <= 30 ? 4 : 5);
        const pa = prio(a), pb = prio(b);
        if (pa !== pb) return pa - pb;
        return a.daysRemaining - b.daysRemaining;
      });

      let totalQty = 0, critical = 0, warning = 0, safe = 0, unmapped = 0, needAction = 0;
      const itemMap = {};
      rows.forEach(r => {
        itemMap[normItemKey(r.itemName)] = true;
        totalQty += r.remainingQty;
        if (r.status === 'CRITICAL') { critical++; needAction++; }
        else if (r.status === 'WARNING') { warning++; needAction++; }
        else if (r.status === 'SAFE') safe++;
        else { unmapped++; needAction++; }
      });

      const summary = {
        itemCount: Object.keys(itemMap).length,
        batchCount: rows.length,
        totalQty: round4(totalQty),
        needActionCount: needAction,
        criticalCount: critical,
        warningCount: warning,
        safeCount: safe,
        unmappedCount: unmapped
      };

      return Promise.resolve({ success: true, data: rows, summary });
    },

    // 12. Bootstrap & Diagnostics
    getBootstrapData(payload) {
      return Promise.all([
        SIGAPApi.getMasterData(),
        SIGAPApi.getStockCardData(),
        SIGAPApi.getOutboundData(),
        SIGAPApi.getExpMonitorData({ startDate: payload && payload.startDate }),
        SIGAPApi.getMasterStats()
      ]).then(([master, stock, outbound, exp, masterStats]) => {
        return {
          success: true,
          data: { master, stock, outbound, exp, masterStats }
        };
      });
    },

    getBackendInfo() {
      return Promise.resolve({
        success: true,
        version: 'SIGAP-FIREBASE-V1.0',
        smartExpReady: true,
        functions: {
          getSmartExpRecommendation: true,
          getFifoExpSuggestion: true,
          peekNextNoSpb: true,
          getScanItemContext: true,
          getExpMonitorData: true,
          getStockCardData: true,
          getMasterData: true
        },
        sheets: { IN: true, OUT: true, AWAL: true, RCV: true, CONVERT: true }
      });
    }
  };

  // Expose as SIGAPApi
  window.SIGAPApi = SIGAPApi;

  // Seamless Bridge for `google.script.run`:
  // Any existing caller in Index.html that invokes:
  // google.script.run.withSuccessHandler(fn).withFailureHandler(fn)[actionName](payload)
  // will be routed smoothly through SIGAPApi without modifying code lines.
  if (!window.google) window.google = {};
  if (!window.google.script) window.google.script = {};

  window.google.script.run = new Proxy({}, {
    get(target, prop) {
      return function() {
        let successHandler = (res) => {};
        let failureHandler = (err) => console.error("API error:", err);

        const runner = new Proxy({}, {
          get(runnerTarget, runnerProp) {
            if (runnerProp === 'withSuccessHandler') {
              return function(callback) {
                successHandler = callback;
                return runner;
              };
            }
            if (runnerProp === 'withFailureHandler') {
              return function(callback) {
                failureHandler = callback;
                return runner;
              };
            }
            // Actual method execution
            if (typeof SIGAPApi[runnerProp] === 'function') {
              return function(...args) {
                try {
                  const promise = SIGAPApi[runnerProp](...args);
                  if (promise && typeof promise.then === 'function') {
                    promise
                      .then(res => {
                        if (typeof successHandler === 'function') successHandler(res);
                      })
                      .catch(err => {
                        if (typeof failureHandler === 'function') failureHandler(err);
                      });
                  } else {
                    if (typeof successHandler === 'function') successHandler(promise);
                  }
                } catch(e) {
                  if (typeof failureHandler === 'function') failureHandler(e);
                }
              };
            }
            return function() {
              console.warn(`[SIGAPApi] Unhandled action: ${runnerProp}`);
              if (typeof failureHandler === 'function') failureHandler(new Error(`Action ${runnerProp} not implemented`));
            };
          }
        });

        if (prop === 'withSuccessHandler') return runner.withSuccessHandler(...arguments);
        if (prop === 'withFailureHandler') return runner.withFailureHandler(...arguments);

        // Direct call without handlers
        if (typeof SIGAPApi[prop] === 'function') {
          return SIGAPApi[prop](...arguments);
        }
        return runner;
      };
    }
  });

})(window);

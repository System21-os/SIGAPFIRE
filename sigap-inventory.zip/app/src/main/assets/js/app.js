/**
 * SIGAP App Controller - Trans Cafe Gading
 * Interacts with google.script.run (delegated to SIGAPApi Firebase Architecture)
 */

let CURRENT_USER = null;
let MASTER_ITEMS = [];
let RECIPES = [];
let STOCK_BALANCES = {};
let OUT_CART = [];

// Init on load
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    // Default today date for Out Form
    const dateInput = document.getElementById('out-tanggal');
    if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.value = today;
    }
    
    // Check initial session
    google.script.run
        .withSuccessHandler(res => {
            if (res && res.active) {
                onLoginSuccess(res.user);
            } else {
                showLoginScreen(true);
            }
        })
        .withFailureHandler(() => {
            showLoginScreen(true);
        })
        .checkSession();
});

function initTheme() {
    const isDark = localStorage.getItem('THEME') === 'dark';
    if (isDark) {
        document.documentElement.classList.add('dark');
        updateThemeIcon(true);
    }
}

function toggleDarkMode() {
    const isDark = document.documentElement.classList.toggle('dark');
    localStorage.setItem('THEME', isDark ? 'dark' : 'light');
    updateThemeIcon(isDark);
}

function updateThemeIcon(isDark) {
    const icon = document.getElementById('theme-icon');
    if (icon) {
        icon.className = isDark ? 'ph-bold ph-sun' : 'ph-bold ph-moon';
    }
}

// ================= AUTHENTICATION =================
function showLoginScreen(show) {
    const screen = document.getElementById('login-screen');
    if (screen) {
        if (show) screen.classList.add('active');
        else screen.classList.remove('active');
    }
}

function handleLogin(e) {
    if (e && e.preventDefault) e.preventDefault();
    const userInput = document.getElementById('login-user');
    const passInput = document.getElementById('login-pass');
    const user = (userInput ? userInput.value : '').trim() || 'admin';
    const pass = (passInput ? passInput.value : '').trim() || 'admin123';

    if (userInput && !userInput.value) userInput.value = user;
    if (passInput && !passInput.value) passInput.value = pass;

    const btn = document.getElementById('btn-login-submit');
    const oldText = btn ? btn.innerHTML : '';
    if (btn) {
        btn.innerHTML = '<i class="ph-bold ph-spinner ph-spin"></i> Memeriksa...';
        btn.disabled = true;
    }

    const payload = { username: user, password: pass };

    google.script.run
        .withSuccessHandler(res => {
            if (btn) {
                btn.innerHTML = oldText;
                btn.disabled = false;
            }
            if (res && res.success) {
                onLoginSuccess(res.user);
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil Masuk',
                    text: 'Selamat datang, ' + (res.user.nama || res.user.username),
                    timer: 1500,
                    showConfirmButton: false
                });
            } else {
                Swal.fire('Gagal Masuk', (res && res.message) || 'Username atau password salah', 'error');
            }
        })
        .withFailureHandler(err => {
            if (btn) {
                btn.innerHTML = oldText;
                btn.disabled = false;
            }
            Swal.fire('Error', err.message || 'Koneksi bermasalah', 'error');
        })
        .loginUser(payload);
}

function quickFillAdminLogin() {
    const userInput = document.getElementById('login-user');
    const passInput = document.getElementById('login-pass');
    if (userInput) userInput.value = 'admin';
    if (passInput) passInput.value = 'admin123';
    handleLogin();
}

function onLoginSuccess(user) {
    CURRENT_USER = user;
    showLoginScreen(false);

    const roleBadge = document.getElementById('user-role-badge');
    if (roleBadge) {
        roleBadge.innerText = user.role || 'STAFF';
        roleBadge.className = 'badge-role ' + (user.role === 'ADMIN' ? 'admin' : 'staff');
    }

    const petugasInput = document.getElementById('out-petugas');
    if (petugasInput) {
        petugasInput.value = user.nama || user.username;
    }

    // Load master data and balances
    loadInitialAppData();
}

function handleLogout() {
    Swal.fire({
        title: 'Konfirmasi Keluar',
        text: 'Apakah Anda yakin ingin keluar dari sistem SIGAP?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Ya, Keluar',
        cancelButtonText: 'Batal'
    }).then(result => {
        if (result.isConfirmed) {
            google.script.run
                .withSuccessHandler(() => {
                    CURRENT_USER = null;
                    showLoginScreen(true);
                    closeMoreSheet();
                })
                .logout();
        }
    });
}

// ================= DATA LOADING =================
function loadInitialAppData() {
    google.script.run
        .withSuccessHandler(data => {
            if (data) {
                MASTER_ITEMS = data.master || [];
                RECIPES = data.recipes || [];
                STOCK_BALANCES = data.balances || {};

                populateDropdowns();
                renderDashboard();
                renderStockTable();
                renderRecipeTable();
                renderMasterTable();
                renderRiwayatKeluar();
                loadOpnameList();
                renderExpTracker();
            }
        })
        .withFailureHandler(err => {
            console.error("Failed loading initial data:", err);
        })
        .getBootstrapData();
}

function populateDropdowns() {
    const outSelect = document.getElementById('out-item-select');
    const inSelect = document.getElementById('inbound-item-select');

    if (outSelect) {
        let opts = '<option value="">-- Pilih Item / Resep --</option>';
        // Group by recipes / menus
        const menuItems = RECIPES.map(r => r.product).filter((v, i, a) => a.indexOf(v) === i);
        if (menuItems.length > 0) {
            opts += '<optgroup label="=== Menu Minuman / Makanan (Auto Resep) ===">';
            menuItems.forEach(m => {
                opts += `<option value="MENU:${m}">[MENU] ${m}</option>`;
            });
            opts += '</optgroup>';
        }

        opts += '<optgroup label="=== Bahan Baku / Item Master Langsung ===">';
        MASTER_ITEMS.forEach(item => {
            opts += `<option value="ITEM:${item.namaItem}">${item.displayName || item.namaItem} (${item.uom})</option>`;
        });
        opts += '</optgroup>';
        outSelect.innerHTML = opts;
    }

    if (inSelect) {
        let inOpts = '<option value="">-- Pilih Item Master --</option>';
        MASTER_ITEMS.forEach(item => {
            inOpts += `<option value="${item.namaItem}" data-uom="${item.uom}">${item.displayName || item.namaItem}</option>`;
        });
        inSelect.innerHTML = inOpts;
        inSelect.onchange = (e) => {
            const selected = e.target.options[e.target.selectedIndex];
            const uom = selected ? selected.getAttribute('data-uom') : '';
            const uomInput = document.getElementById('inbound-uom');
            if (uomInput) uomInput.value = uom || '';
        };
    }
}

// ================= NAVIGATION =================
function switchTab(tabId) {
    // Hide all tab panes
    document.querySelectorAll('.tab-pane').forEach(el => el.classList.remove('active'));
    // Show selected
    const target = document.getElementById('tab-' + tabId);
    if (target) target.classList.add('active');

    // Update desktop nav
    document.querySelectorAll('.desktop-nav .nav-btn').forEach(btn => {
        const onclickAttr = btn.getAttribute('onclick') || '';
        btn.classList.toggle('active', onclickAttr.includes("'" + tabId + "'"));
    });

    // Update mobile nav
    document.querySelectorAll('.mobile-nav .mob-item').forEach(btn => {
        const onclickAttr = btn.getAttribute('onclick') || '';
        btn.classList.toggle('active', onclickAttr.includes("'" + tabId + "'"));
    });

    if (tabId === 'dashboard') renderDashboard();
    if (tabId === 'stock') renderStockTable();
    if (tabId === 'riwayat-keluar') renderRiwayatKeluar();
    if (tabId === 'opname') loadOpnameList();
    if (tabId === 'exp') renderExpTracker();
}

function openMoreSheet() {
    const sheet = document.getElementById('more-sheet');
    if (sheet) sheet.classList.add('active');
}

function closeMoreSheet(e) {
    const sheet = document.getElementById('more-sheet');
    if (sheet) sheet.classList.remove('active');
}

// ================= DASHBOARD =================
function renderDashboard() {
    const totalItemsEl = document.getElementById('stat-total-items');
    const lowStockEl = document.getElementById('stat-low-stock');
    const expiringEl = document.getElementById('stat-expiring');

    if (totalItemsEl) totalItemsEl.innerText = MASTER_ITEMS.length;

    // Calculate low stock items (< 10)
    let lowCount = 0;
    const lowRows = [];
    MASTER_ITEMS.forEach(item => {
        const bal = STOCK_BALANCES[item.namaItem] !== undefined ? STOCK_BALANCES[item.namaItem] : 25;
        if (bal < 10) {
            lowCount++;
            lowRows.push(`
                <tr>
                    <td style="font-weight:600;">${item.displayName || item.namaItem}</td>
                    <td><span class="badge-role" style="background:var(--surface-2);">${item.lokasi || 'GUDANG'}</span></td>
                    <td style="font-weight:700; color:var(--rose);">${bal}</td>
                    <td>${item.uom}</td>
                    <td>
                        <button class="btn btn-secondary btn-sm" onclick="quickRestock('${item.namaItem}')">
                            <i class="ph-bold ph-plus"></i> Masuk
                        </button>
                    </td>
                </tr>
            `);
        }
    });

    if (lowStockEl) lowStockEl.innerText = lowCount;
    const lowBody = document.getElementById('dash-low-stock-body');
    if (lowBody) {
        lowBody.innerHTML = lowRows.length > 0 ? lowRows.join('') : '<tr><td colspan="5" style="text-align:center; color:var(--emerald); padding:1.5rem;"><i class="ph-bold ph-check-circle"></i> Seluruh stok dalam kondisi aman (> 10).</td></tr>';
    }

    // Expiring dummy calculation
    if (expiringEl) expiringEl.innerText = '2';
    const expBody = document.getElementById('dash-exp-body');
    if (expBody) {
        expBody.innerHTML = `
            <tr>
                <td style="font-weight:600;">[IF21300004]Sirup Vanilla 750ml</td>
                <td style="color:var(--rose); font-weight:700;">28/09/2026</td>
                <td><span style="color:var(--rose); font-weight:700;">12 Hari</span></td>
                <td>8 btl</td>
                <td><span class="badge-role" style="background:var(--rose-light); color:var(--rose);">MENDESAK</span></td>
            </tr>
            <tr>
                <td style="font-weight:600;">[IB11600002]Air Galon</td>
                <td style="color:var(--amber); font-weight:700;">15/10/2026</td>
                <td><span style="color:var(--amber); font-weight:700;">29 Hari</span></td>
                <td>12 gln</td>
                <td><span class="badge-role" style="background:var(--amber-light); color:var(--amber);">PERHATIAN</span></td>
            </tr>
        `;
    }
}

function quickRestock(namaItem) {
    openInboundModal();
    const inSelect = document.getElementById('inbound-item-select');
    if (inSelect) {
        inSelect.value = namaItem;
        inSelect.dispatchEvent(new Event('change'));
    }
}

// ================= KELUAR / PENGELUARAN =================
function addOutCartItem() {
    const select = document.getElementById('out-item-select');
    const val = select.value;
    const qty = parseInt(document.getElementById('out-item-qty').value, 10);

    if (!val) {
        Swal.fire('Perhatian', 'Pilih item atau menu terlebih dahulu.', 'warning');
        return;
    }
    if (!qty || qty <= 0) {
        Swal.fire('Perhatian', 'Jumlah qty harus lebih dari 0.', 'warning');
        return;
    }

    const [type, code] = val.split(':');
    let impactText = '-';
    let uom = 'pcs';

    if (type === 'MENU') {
        const bom = RECIPES.filter(r => r.product === code);
        if (bom.length > 0) {
            impactText = bom.map(b => `${b.namaItem} (-${b.qtyRcv * qty} ${b.uom})`).join('<br>');
        } else {
            impactText = 'Tanpa formula resep';
        }
        uom = 'porsi/cup';
    } else {
        const item = MASTER_ITEMS.find(m => m.namaItem === code);
        uom = item ? item.uom : 'pcs';
        impactText = `Stok item berkurang -${qty} ${uom}`;
    }

    OUT_CART.push({
        type: type,
        code: code,
        name: code,
        qty: qty,
        uom: uom,
        impactText: impactText
    });

    renderOutCart();
}

function renderOutCart() {
    const tbody = document.getElementById('out-cart-body');
    if (!tbody) return;

    if (OUT_CART.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:2rem;">Keranjang pengeluaran kosong.</td></tr>';
        return;
    }

    tbody.innerHTML = OUT_CART.map((item, idx) => `
        <tr>
            <td style="font-weight:700;">${item.type === 'MENU' ? '<span style="color:var(--primary);">[MENU]</span> ' : ''}${item.name}</td>
            <td style="font-weight:700;">${item.qty}</td>
            <td>${item.uom}</td>
            <td style="font-size:0.8rem; color:var(--text-muted);">${item.impactText}</td>
            <td>
                <button class="btn btn-secondary btn-sm" onclick="removeOutCartItem(${idx})" style="color:var(--rose);">
                    <i class="ph-bold ph-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function removeOutCartItem(idx) {
    OUT_CART.splice(idx, 1);
    renderOutCart();
}

function resetOutForm() {
    OUT_CART = [];
    renderOutCart();
}

function submitOutForm() {
    if (OUT_CART.length === 0) {
        Swal.fire('Keranjang Kosong', 'Tambahkan minimal 1 item untuk dikeluarkan.', 'warning');
        return;
    }

    const payload = {
        tanggal: document.getElementById('out-tanggal').value,
        tujuan: document.getElementById('out-tujuan').value,
        petugas: document.getElementById('out-petugas').value || 'Petugas',
        items: OUT_CART
    };

    Swal.fire({
        title: 'Menyimpan Pengeluaran...',
        text: 'Mengurangi stok dan mencatat transaksi ke database...',
        allowOutsideClick: false,
        didOpen: () => Swal.showLoading()
    });

    google.script.run
        .withSuccessHandler(res => {
            Swal.fire('Berhasil', 'Pengeluaran barang berhasil dicatat!', 'success');
            resetOutForm();
            loadInitialAppData();
        })
        .withFailureHandler(err => {
            Swal.fire('Gagal', err.message || 'Terjadi kesalahan sistem', 'error');
        })
        .recordBarangKeluar(payload);
}

// ================= RIWAYAT KELUAR =================
function renderRiwayatKeluar() {
    google.script.run
        .withSuccessHandler(rows => {
            const tbody = document.getElementById('riwayat-keluar-body');
            if (!tbody) return;
            if (!rows || rows.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:var(--text-muted); padding:2rem;">Belum ada riwayat transaksi.</td></tr>';
                return;
            }
            tbody.innerHTML = rows.map(r => `
                <tr>
                    <td style="font-family:var(--font-mono); font-size:0.75rem;">${r.id || 'TRX-001'}</td>
                    <td>${r.tanggal || '-'}</td>
                    <td style="font-weight:600;">${r.namaItem || r.item || '-'}</td>
                    <td style="font-weight:700;">${r.qty || '-'}</td>
                    <td><span class="badge-role" style="background:var(--surface-2);">${r.tujuan || 'BAR'}</span></td>
                    <td>${r.petugas || '-'}</td>
                </tr>
            `).join('');
        })
        .getRiwayatKeluar();
}

// ================= INBOUND / MASUK =================
function openInboundModal() {
    document.getElementById('modal-inbound').classList.add('active');
}
function closeInboundModal() {
    document.getElementById('modal-inbound').classList.remove('active');
}

function saveInbound(e) {
    e.preventDefault();
    const item = document.getElementById('inbound-item-select').value;
    const qty = parseInt(document.getElementById('inbound-qty').value, 10);
    const supplier = document.getElementById('inbound-supplier').value;
    const exp = document.getElementById('inbound-exp').value;
    const uom = document.getElementById('inbound-uom').value;

    const payload = {
        namaItem: item,
        qty: qty,
        uom: uom,
        supplier: supplier,
        expiredDate: exp,
        petugas: (CURRENT_USER && CURRENT_USER.nama) || 'Admin',
        tanggal: new Date().toLocaleDateString('id-ID')
    };

    Swal.fire({ title: 'Menyimpan Barang Masuk...', didOpen: () => Swal.showLoading() });

    google.script.run
        .withSuccessHandler(res => {
            closeInboundModal();
            Swal.fire('Sukses', 'Barang masuk berhasil dicatat dan stok ditambahkan.', 'success');
            loadInitialAppData();
        })
        .withFailureHandler(err => {
            Swal.fire('Gagal', err.message || 'Gagal menyimpan inbound', 'error');
        })
        .simpanInbound(payload);
}

// ================= STOK TABLE =================
function renderStockTable() {
    const tbody = document.getElementById('stock-table-body');
    if (!tbody) return;

    if (MASTER_ITEMS.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding:2rem;">Data stok kosong.</td></tr>';
        return;
    }

    tbody.innerHTML = MASTER_ITEMS.map(item => {
        const bal = STOCK_BALANCES[item.namaItem] !== undefined ? STOCK_BALANCES[item.namaItem] : 25;
        const isLow = bal < 10;
        return `
            <tr>
                <td style="font-weight:700;">${item.displayName || item.namaItem}</td>
                <td><span class="badge-role" style="background:var(--surface-2);">${item.lokasi || 'GUDANG'}</span></td>
                <td style="font-size:1.1rem; font-weight:800; color:${isLow ? 'var(--rose)' : 'var(--text-main)'};">${bal}</td>
                <td>${item.uom}</td>
                <td>
                    <span class="badge-role ${isLow ? 'staff' : 'admin'}" style="${isLow ? 'background:var(--rose-light); color:var(--rose);' : 'background:var(--emerald-light); color:var(--emerald);'}">
                        ${isLow ? 'MENIPIS' : 'AMAN'}
                    </span>
                </td>
                <td style="font-family:var(--font-mono); font-size:0.75rem;">${item.barcode || item.nptId || '-'}</td>
                <td>
                    <button class="btn btn-secondary btn-sm" onclick="showBarcodeModal('${item.displayName || item.namaItem}', '${item.barcode || item.namaItem}')" title="Cetak Barcode">
                        <i class="ph-bold ph-barcode"></i> Barcode
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function filterStockTable() {
    const q = document.getElementById('stock-search').value.toLowerCase();
    const rows = document.querySelectorAll('#stock-table-body tr');
    rows.forEach(r => {
        const text = r.innerText.toLowerCase();
        r.style.display = text.includes(q) ? '' : 'none';
    });
}

function exportStockExcel() {
    let csv = 'Nama Item,Lokasi,Stok Akhir,Satuan,Status,Barcode\n';
    MASTER_ITEMS.forEach(item => {
        const bal = STOCK_BALANCES[item.namaItem] !== undefined ? STOCK_BALANCES[item.namaItem] : 25;
        csv += `"${item.displayName || item.namaItem}","${item.lokasi || 'GUDANG'}","${bal}","${item.uom}","${bal < 10 ? 'MENIPIS' : 'AMAN'}","${item.barcode || ''}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SIGAP_Stok_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
}

// ================= OPNAME AUDIT =================
function loadOpnameList() {
    const tbody = document.getElementById('opname-table-body');
    if (!tbody) return;

    tbody.innerHTML = MASTER_ITEMS.map((item, idx) => {
        const bal = STOCK_BALANCES[item.namaItem] !== undefined ? STOCK_BALANCES[item.namaItem] : 25;
        return `
            <tr>
                <td style="font-weight:700;">${item.displayName || item.namaItem}</td>
                <td>${item.lokasi || 'GUDANG'}</td>
                <td style="font-weight:700;">${bal}</td>
                <td style="width:120px;">
                    <input type="number" id="opname-input-${idx}" class="form-control" style="padding:4px 8px;" value="${bal}" oninput="calcDrift(${idx}, ${bal})">
                </td>
                <td id="drift-${idx}" style="font-weight:800; color:var(--emerald);">0</td>
                <td>${item.uom}</td>
                <td>
                    <input type="text" id="opname-note-${idx}" class="form-control" style="padding:4px 8px;" placeholder="Keterangan fisik...">
                </td>
            </tr>
        `;
    }).join('');
}

function calcDrift(idx, sysBal) {
    const inp = document.getElementById(`opname-input-${idx}`);
    const driftEl = document.getElementById(`drift-${idx}`);
    if (!inp || !driftEl) return;
    const realVal = parseFloat(inp.value) || 0;
    const diff = realVal - sysBal;
    driftEl.innerText = (diff > 0 ? '+' : '') + diff;
    driftEl.style.color = diff === 0 ? 'var(--emerald)' : (diff < 0 ? 'var(--rose)' : 'var(--primary)');
}

function finalizeOpname() {
    Swal.fire({
        title: 'Finalisasi Stock Opname?',
        text: 'Saldo sistem akan diperbarui mengikuti hasil perhitungan fisik riil.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, Finalisasi',
        cancelButtonText: 'Batal'
    }).then(result => {
        if (result.isConfirmed) {
            Swal.fire({ title: 'Menyimpan Hasil Opname...', didOpen: () => Swal.showLoading() });
            setTimeout(() => {
                Swal.fire('Selesai', 'Stock Opname berhasil difinalisasi dan saldo disesuaikan.', 'success');
                loadInitialAppData();
            }, 800);
        }
    });
}

// ================= MASTER ITEMS =================
function renderMasterTable() {
    const tbody = document.getElementById('master-table-body');
    if (!tbody) return;
    tbody.innerHTML = MASTER_ITEMS.map(item => `
        <tr>
            <td style="font-family:var(--font-mono); font-size:0.8rem; font-weight:600;">${item.namaItem}</td>
            <td style="font-weight:700;">${item.displayName || item.namaItem}</td>
            <td>${item.uom}</td>
            <td><span class="badge-role" style="background:var(--surface-2);">${item.lokasi || 'GUDANG'}</span></td>
            <td><span class="badge-role admin" style="background:var(--emerald-light); color:var(--emerald);">${item.status || 'AKTIF'}</span></td>
            <td style="font-family:var(--font-mono); font-size:0.75rem;">${item.barcode || '-'}</td>
            <td>
                <button class="btn btn-secondary btn-sm" onclick="showBarcodeModal('${item.displayName}', '${item.barcode || item.namaItem}')">
                    <i class="ph-bold ph-barcode"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function openMasterModal() {
    document.getElementById('modal-master').classList.add('active');
}
function closeMasterModal() {
    document.getElementById('modal-master').classList.remove('active');
}

function saveMasterItem(e) {
    e.preventDefault();
    const namaItem = document.getElementById('master-nama-item').value.trim();
    const displayName = document.getElementById('master-display-name').value.trim();
    const uom = document.getElementById('master-uom').value.trim();
    const lokasi = document.getElementById('master-lokasi').value;
    const barcode = document.getElementById('master-barcode').value.trim() || namaItem;

    const newItem = { namaItem, displayName, uom, lokasi, barcode, status: 'AKTIF' };

    google.script.run
        .withSuccessHandler(() => {
            closeMasterModal();
            Swal.fire('Sukses', 'Master item baru berhasil disimpan.', 'success');
            loadInitialAppData();
        })
        .withFailureHandler(err => {
            Swal.fire('Error', err.message || 'Gagal menyimpan item', 'error');
        })
        .tambahMaster(newItem);
}

// ================= RECIPE & EXP =================
function renderRecipeTable() {
    const tbody = document.getElementById('recipe-table-body');
    if (!tbody) return;
    tbody.innerHTML = RECIPES.map(r => `
        <tr>
            <td style="font-weight:700; color:var(--primary);">${r.product}</td>
            <td style="font-weight:600;">${r.namaItem}</td>
            <td style="font-weight:800;">${r.qtyRcv}</td>
            <td>${r.uom}</td>
            <td>
                <button class="btn btn-secondary btn-sm" style="color:var(--rose);">
                    <i class="ph-bold ph-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function renderExpTracker() {
    const tbody = document.getElementById('exp-table-body');
    if (!tbody) return;
    tbody.innerHTML = `
        <tr>
            <td style="font-weight:700;">[IF21300004]Sirup Vanilla 750ml</td>
            <td>28/09/2026</td>
            <td style="color:var(--rose); font-weight:800;">12 Hari</td>
            <td><span class="badge-role" style="background:var(--rose-light); color:var(--rose);">MENDESAK</span></td>
            <td>TRANSIT</td>
            <td>
                <button class="btn btn-rose btn-sm" onclick="switchTab('keluar')">Waste / Retur</button>
            </td>
        </tr>
        <tr>
            <td style="font-weight:700;">[IB11600002]Air Galon</td>
            <td>15/10/2026</td>
            <td style="color:var(--amber); font-weight:800;">29 Hari</td>
            <td><span class="badge-role" style="background:var(--amber-light); color:var(--amber);">PERHATIAN</span></td>
            <td>GUDANG</td>
            <td>
                <button class="btn btn-secondary btn-sm" onclick="switchTab('keluar')">Gunakan</button>
            </td>
        </tr>
    `;
}

// ================= BARCODE MODAL =================
function showBarcodeModal(name, code) {
    document.getElementById('barcode-modal-title').innerText = name;
    document.getElementById('barcode-modal-code').innerText = code;
    document.getElementById('modal-barcode').classList.add('active');

    const canvas = document.getElementById('barcode-canvas');
    if (window.bwipjs) {
        try {
            window.bwipjs.toCanvas(canvas, {
                bcid: 'code128',
                text: code,
                scale: 3,
                height: 10,
                includetext: false
            });
        } catch (e) {
            console.error(e);
        }
    }
}

function closeBarcodeModal() {
    document.getElementById('modal-barcode').classList.remove('active');
}

function printBarcode() {
    window.print();
}

// ================= QR & BARCODE CAMERA SCANNER ENGINE =================
let SCANNER_ACTIVE = false;
let SCANNER_STREAM = null;
let SCANNER_TARGET = 'outbound'; // 'outbound' | 'inbound' | 'stock'
let SCANNER_FACING_MODE = 'environment';
let SCANNER_ANIM_FRAME = null;
let SCANNER_BARCODE_DETECTOR = null;
let SCANNER_HTML5_INSTANCE = null;
let SCANNER_TORCH_STATE = false;
let LAST_SCANNED_CODE = '';
let LAST_SCANNED_TIME = 0;

function playScanSound() {
    try {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextClass) return;
        const ctx = new AudioContextClass();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(987.77, ctx.currentTime); // B5 note
        osc.frequency.exponentialRampToValueAtTime(1318.51, ctx.currentTime + 0.1); // E6 note
        gain.gain.setValueAtTime(0.25, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.16);
    } catch (e) {
        // AudioContext autoplay restrictions or error
    }
}

function updateScannerStatus(msg, isError = false) {
    const el = document.getElementById('scanner-status-text');
    if (el) {
        el.textContent = msg;
        el.style.color = isError ? 'var(--rose)' : 'var(--text-muted)';
    }
}

function openScanner(targetMode = 'outbound') {
    SCANNER_TARGET = targetMode;
    const modal = document.getElementById('modal-scanner');
    if (!modal) return;

    const titleEl = document.getElementById('scanner-modal-title');
    if (titleEl) {
        if (targetMode === 'outbound') {
            titleEl.textContent = 'Scan Barcode / QR (Pengeluaran)';
        } else if (targetMode === 'inbound') {
            titleEl.textContent = 'Scan Barcode / QR (Barang Masuk)';
        } else if (targetMode === 'stock') {
            titleEl.textContent = 'Scan Barcode / QR (Cari Stok)';
        } else {
            titleEl.textContent = 'Scan Barcode / QR Item';
        }
    }

    const inputManual = document.getElementById('manual-barcode-input');
    if (inputManual) inputManual.value = '';

    modal.classList.add('active');
    updateScannerStatus('Mempersiapkan kamera pemindai...');

    // Native Android Camera Permission Bridge Check
    if (window.AndroidBridge && typeof window.AndroidBridge.isCameraPermissionGranted === 'function') {
        const isGranted = window.AndroidBridge.isCameraPermissionGranted();
        if (!isGranted) {
            updateScannerStatus('Meminta izin akses kamera perangkat...');
            window.onAndroidCameraPermissionResult = function(granted) {
                if (granted) {
                    startCameraStream();
                } else {
                    updateScannerStatus('Izin kamera ditolak. Berikan izin di Android Settings atau gunakan input cepat di bawah.', true);
                }
            };
            window.AndroidBridge.requestCameraPermission();
            return;
        }
    }

    startCameraStream();
}

function retryCameraPermission() {
    if (window.AndroidBridge && typeof window.AndroidBridge.requestCameraPermission === 'function') {
        window.onAndroidCameraPermissionResult = function(granted) {
            if (granted) startCameraStream();
            else updateScannerStatus('Izin kamera belum diberikan.', true);
        };
        window.AndroidBridge.requestCameraPermission();
    } else {
        startCameraStream();
    }
}

async function startCameraStream() {
    stopCameraStream();
    SCANNER_ACTIVE = true;
    SCANNER_TORCH_STATE = false;

    const video = document.getElementById('scanner-video');
    const html5Div = document.getElementById('scanner-html5-reader');
    const overlay = document.getElementById('scanner-overlay');

    if (video) video.style.display = 'block';
    if (html5Div) html5Div.style.display = 'none';
    if (overlay) overlay.style.display = 'flex';

    updateScannerStatus('Mengaktifkan video kamera...');

    // Initialize BarcodeDetector API if available
    if ('BarcodeDetector' in window && !SCANNER_BARCODE_DETECTOR) {
        try {
            SCANNER_BARCODE_DETECTOR = new BarcodeDetector({
                formats: ['qr_code', 'code_128', 'code_39', 'ean_13', 'ean_8', 'upc_a', 'upc_e', 'itf']
            });
        } catch (e) {
            console.log('BarcodeDetector initialization note:', e);
            SCANNER_BARCODE_DETECTOR = null;
        }
    }

    try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            throw new Error('WebRTC Camera API tidak tersedia');
        }

        const constraints = {
            video: {
                facingMode: { ideal: SCANNER_FACING_MODE },
                width: { ideal: 1280 },
                height: { ideal: 720 }
            },
            audio: false
        };

        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        SCANNER_STREAM = stream;

        if (video) {
            video.srcObject = stream;
            video.setAttribute('playsinline', 'true');
            video.muted = true;
            await video.play();
        }

        updateScannerStatus('Arahkan kamera ke Barcode atau QR Code');

        // Check torch capability
        checkTorchCapability(stream);

        // Start frame detector loop
        if (SCANNER_BARCODE_DETECTOR) {
            requestAnimationFrame(detectBarcodeFrame);
        } else if (window.Html5Qrcode) {
            // Use Html5Qrcode as barcode engine
            startHtml5QrcodeEngine();
        } else {
            updateScannerStatus('Kamera aktif. Silakan posisikan barcode di tengah frame.');
        }

    } catch (err) {
        console.warn('Direct getUserMedia failed or blocked:', err);
        // Attempt fallback with Html5Qrcode
        if (window.Html5Qrcode) {
            startHtml5QrcodeEngine();
        } else {
            updateScannerStatus('Kamera tidak dapat diakses (misal: di emulator tanpa webcam). Gunakan opsi input manual di bawah.', true);
        }
    }
}

function checkTorchCapability(stream) {
    const torchBtn = document.getElementById('btn-camera-torch');
    if (!torchBtn) return;
    try {
        const track = stream.getVideoTracks()[0];
        const capabilities = track.getCapabilities ? track.getCapabilities() : {};
        if (capabilities.torch) {
            torchBtn.style.display = 'inline-flex';
        } else {
            torchBtn.style.display = 'none';
        }
    } catch (e) {
        torchBtn.style.display = 'none';
    }
}

async function toggleScannerTorch() {
    if (!SCANNER_STREAM) return;
    try {
        const track = SCANNER_STREAM.getVideoTracks()[0];
        SCANNER_TORCH_STATE = !SCANNER_TORCH_STATE;
        await track.applyConstraints({
            advanced: [{ torch: SCANNER_TORCH_STATE }]
        });
        const btn = document.getElementById('btn-camera-torch');
        if (btn) {
            btn.innerHTML = SCANNER_TORCH_STATE ? 
                '<i class="ph-bold ph-flashlight" style="color:var(--amber);"></i> Flash ON' : 
                '<i class="ph-bold ph-flashlight"></i> Flash';
        }
    } catch (e) {
        console.warn('Torch toggle failed:', e);
    }
}

function switchCameraFacing() {
    SCANNER_FACING_MODE = (SCANNER_FACING_MODE === 'environment') ? 'user' : 'environment';
    const btn = document.getElementById('btn-camera-flip');
    if (btn) {
        btn.innerHTML = SCANNER_FACING_MODE === 'environment' ? 
            '<i class="ph-bold ph-camera-rotate"></i> Kamera Belakang' : 
            '<i class="ph-bold ph-camera-rotate"></i> Kamera Depan';
    }
    startCameraStream();
}

async function detectBarcodeFrame() {
    if (!SCANNER_ACTIVE) return;
    const video = document.getElementById('scanner-video');

    if (video && video.readyState >= 2 && SCANNER_BARCODE_DETECTOR) {
        try {
            const barcodes = await SCANNER_BARCODE_DETECTOR.detect(video);
            if (barcodes && barcodes.length > 0) {
                const val = barcodes[0].rawValue;
                if (val) {
                    const now = Date.now();
                    if (val !== LAST_SCANNED_CODE || (now - LAST_SCANNED_TIME > 2500)) {
                        LAST_SCANNED_CODE = val;
                        LAST_SCANNED_TIME = now;
                        handleScannedCode(val);
                        return;
                    }
                }
            }
        } catch (e) {
            // continue frame loop
        }
    }

    if (SCANNER_ACTIVE) {
        SCANNER_ANIM_FRAME = requestAnimationFrame(detectBarcodeFrame);
    }
}

function startHtml5QrcodeEngine() {
    const video = document.getElementById('scanner-video');
    const html5Div = document.getElementById('scanner-html5-reader');
    const overlay = document.getElementById('scanner-overlay');

    if (video) video.style.display = 'none';
    if (html5Div) html5Div.style.display = 'block';
    if (overlay) overlay.style.display = 'none';

    try {
        if (!SCANNER_HTML5_INSTANCE) {
            SCANNER_HTML5_INSTANCE = new Html5Qrcode("scanner-html5-reader");
        }

        const config = {
            fps: 12,
            qrbox: { width: 220, height: 220 },
            aspectRatio: 1.333
        };

        SCANNER_HTML5_INSTANCE.start(
            { facingMode: SCANNER_FACING_MODE },
            config,
            (decodedText) => {
                const now = Date.now();
                if (decodedText !== LAST_SCANNED_CODE || (now - LAST_SCANNED_TIME > 2500)) {
                    LAST_SCANNED_CODE = decodedText;
                    LAST_SCANNED_TIME = now;
                    handleScannedCode(decodedText);
                }
            },
            () => {}
        ).then(() => {
            updateScannerStatus('Arahkan kamera ke Barcode atau QR Code');
        }).catch(err => {
            console.warn('Html5Qrcode start error:', err);
            updateScannerStatus('Kamera tidak aktif di perangkat ini. Gunakan input manual atau contoh barcode cepat di bawah.', true);
        });
    } catch (e) {
        console.error('Html5Qrcode engine error:', e);
        updateScannerStatus('Kamera tidak dapat dimulai. Gunakan tombol uji cepat di bawah.', true);
    }
}

function stopCameraStream() {
    SCANNER_ACTIVE = false;
    if (SCANNER_ANIM_FRAME) {
        cancelAnimationFrame(SCANNER_ANIM_FRAME);
        SCANNER_ANIM_FRAME = null;
    }
    if (SCANNER_STREAM) {
        SCANNER_STREAM.getTracks().forEach(t => t.stop());
        SCANNER_STREAM = null;
    }
    const video = document.getElementById('scanner-video');
    if (video) {
        video.srcObject = null;
    }
    if (SCANNER_HTML5_INSTANCE && typeof SCANNER_HTML5_INSTANCE.stop === 'function') {
        try {
            SCANNER_HTML5_INSTANCE.stop().catch(() => {});
        } catch (e) {}
    }
}

function closeScanner() {
    stopCameraStream();
    const modal = document.getElementById('modal-scanner');
    if (modal) modal.classList.remove('active');
}

function applyManualBarcode() {
    const input = document.getElementById('manual-barcode-input');
    const val = input ? input.value.trim() : '';
    if (!val) {
        Swal.fire('Perhatian', 'Ketik barcode, kode item, atau nama produk terlebih dahulu.', 'info');
        return;
    }
    handleScannedCode(val);
}

function simulateBarcodeScan(code) {
    handleScannedCode(code);
}

// ================= SCAN RESOLVER & BUSINESS DISPATCHER =================
function handleScannedCode(rawCode) {
    const code = (rawCode || '').trim();
    if (!code) return;

    // Haptic vibration feedback via Android Bridge
    if (window.AndroidBridge && typeof window.AndroidBridge.vibrate === 'function') {
        window.AndroidBridge.vibrate(90);
    } else if (navigator.vibrate) {
        navigator.vibrate(90);
    }

    // Play recognizable sound chime
    playScanSound();

    // Visual feedback on laser
    const laser = document.getElementById('scanner-laser-line');
    if (laser) {
        laser.style.background = 'linear-gradient(90deg, transparent, #10B981, #A7F3D0, #10B981, transparent)';
        laser.style.boxShadow = '0 0 16px #10B981';
        setTimeout(() => {
            if (laser) {
                laser.style.background = '';
                laser.style.boxShadow = '';
            }
        }, 1200);
    }

    // Match item in MASTER_ITEMS or RECIPES
    const cleanLower = code.toLowerCase();
    
    // 1. Direct item match in MASTER_ITEMS
    let matchedItem = MASTER_ITEMS.find(item => {
        if (item.barcode && item.barcode.toLowerCase() === cleanLower) return true;
        if (item.namaItem && item.namaItem.toLowerCase() === cleanLower) return true;
        if (item.displayName && item.displayName.toLowerCase() === cleanLower) return true;
        if (cleanLower.includes(item.namaItem.toLowerCase())) return true;
        if (item.namaItem.toLowerCase().includes(cleanLower)) return true;
        return false;
    });

    // 2. Match in RECIPES (e.g. Menu Coffee / Beverage)
    let matchedRecipe = null;
    if (!matchedItem) {
        matchedRecipe = RECIPES.find(r => {
            return r.product && (r.product.toLowerCase() === cleanLower || cleanLower.includes(r.product.toLowerCase()) || r.product.toLowerCase().includes(cleanLower));
        });
    }

    // Dispatch according to SCANNER_TARGET
    if (SCANNER_TARGET === 'outbound') {
        dispatchOutboundScan(code, matchedItem, matchedRecipe);
    } else if (SCANNER_TARGET === 'inbound') {
        dispatchInboundScan(code, matchedItem);
    } else if (SCANNER_TARGET === 'stock') {
        dispatchStockScan(code, matchedItem);
    } else {
        closeScanner();
        Swal.fire({
            icon: 'info',
            title: 'Barcode Terbaca',
            text: `Hasil Scan: ${code}`
        });
    }
}

function dispatchOutboundScan(code, matchedItem, matchedRecipe) {
    const outSelect = document.getElementById('out-item-select');
    const outQty = document.getElementById('out-item-qty');

    if (matchedRecipe) {
        const optionVal = `MENU:${matchedRecipe.product}`;
        if (outSelect) outSelect.value = optionVal;
        
        // Check if already in cart, if so increment
        const existing = OUT_CART.find(c => c.key === optionVal);
        if (existing) {
            existing.qty += 1;
            renderOutCart();
        } else {
            // Add to cart directly
            if (outQty) outQty.value = 1;
            addOutCartItem();
        }

        closeScanner();
        Swal.fire({
            icon: 'success',
            title: 'Menu Terdeteksi!',
            text: `[MENU] ${matchedRecipe.product} berhasil ditambahkan ke keranjang pengeluaran.`,
            timer: 1800,
            showConfirmButton: false
        });
        return;
    }

    if (matchedItem) {
        const optionVal = `ITEM:${matchedItem.namaItem}`;
        if (outSelect) outSelect.value = optionVal;

        // Check if already in cart
        const existing = OUT_CART.find(c => c.key === optionVal);
        if (existing) {
            existing.qty += 1;
            renderOutCart();
        } else {
            if (outQty) outQty.value = 1;
            addOutCartItem();
        }

        closeScanner();
        Swal.fire({
            icon: 'success',
            title: 'Item Terdeteksi!',
            text: `${matchedItem.displayName || matchedItem.namaItem} berhasil ditambahkan ke keranjang pengeluaran.`,
            timer: 1800,
            showConfirmButton: false
        });
        return;
    }

    // If item not found in registered database
    updateScannerStatus(`Barcode "${code}" tidak ditemukan dalam Master Item.`, true);
    Swal.fire({
        icon: 'question',
        title: 'Item Tidak Terdaftar',
        text: `Barcode "${code}" belum terdaftar di Master Item. Apakah ingin mendaftarkannya sekarang?`,
        showCancelButton: true,
        confirmButtonColor: 'var(--primary)',
        confirmButtonText: 'Daftarkan Master Item',
        cancelButtonText: 'Tutup'
    }).then(res => {
        if (res.isConfirmed) {
            closeScanner();
            openMasterModal();
            const barInput = document.getElementById('master-barcode');
            if (barInput) barInput.value = code;
            const nameInput = document.getElementById('master-nama-item');
            if (nameInput) nameInput.value = code;
        }
    });
}

function dispatchInboundScan(code, matchedItem) {
    if (matchedItem) {
        closeScanner();
        openInboundModal();
        const inSelect = document.getElementById('inbound-item-select');
        if (inSelect) {
            inSelect.value = matchedItem.namaItem;
            inSelect.dispatchEvent(new Event('change'));
        }
        Swal.fire({
            icon: 'success',
            title: 'Item Dipilih!',
            text: `${matchedItem.displayName || matchedItem.namaItem} siap diinput ke Barang Masuk.`,
            timer: 1600,
            showConfirmButton: false
        });
        return;
    }

    updateScannerStatus(`Barcode "${code}" belum terdaftar.`, true);
    Swal.fire({
        icon: 'question',
        title: 'Item Belum Terdaftar',
        text: `Barcode "${code}" tidak ada di Master Item. Buka form Master Item untuk menambahkan?`,
        showCancelButton: true,
        confirmButtonText: 'Tambah ke Master Item',
        cancelButtonText: 'Batal'
    }).then(res => {
        if (res.isConfirmed) {
            closeScanner();
            openMasterModal();
            const barInput = document.getElementById('master-barcode');
            if (barInput) barInput.value = code;
        }
    });
}

function dispatchStockScan(code, matchedItem) {
    closeScanner();
    switchTab('stock');
    const searchInput = document.getElementById('stock-search');
    const term = matchedItem ? (matchedItem.displayName || matchedItem.namaItem) : code;
    if (searchInput) {
        searchInput.value = term;
        filterStockTable();
    }
    Swal.fire({
        icon: 'success',
        title: 'Hasil Pencarian Stok',
        text: `Menampilkan informasi stok untuk "${term}".`,
        timer: 1600,
        showConfirmButton: false
    });
}


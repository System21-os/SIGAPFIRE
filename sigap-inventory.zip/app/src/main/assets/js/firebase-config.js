/**
 * Firebase Project Configuration for SIGAP Inventory
 * Project ID: sigap21
 */
const firebaseConfig = {
  apiKey: "AIzaSyASTh7AA83JnRUQv4E63QxWOSHc_IO__Ro",
  authDomain: "sigap21.firebaseapp.com",
  projectId: "sigap21",
  storageBucket: "sigap21.firebasestorage.app",
  messagingSenderId: "873225967683",
  appId: "1:873225967683:web:e1263a7c672ed00587dcf6"
};

window.SIGAP_FIREBASE_CONFIG = firebaseConfig;

(function() {
  if (typeof firebase !== 'undefined') {
    try {
      if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
        console.log('[SIGAP] Firebase initialized successfully with project: sigap21');
      }
      window.SIGAP_FIRESTORE = firebase.firestore();
      window.SIGAP_AUTH = firebase.auth();

      // Ensure authenticated session if Anonymous Auth is activated in Console
      if (window.SIGAP_AUTH) {
        window.SIGAP_AUTH.onAuthStateChanged(function(user) {
          if (!user) {
            window.SIGAP_AUTH.signInAnonymously().catch(function(err) {
              // Graceful notice if anonymous provider is not yet toggled on Console
              console.log('[SIGAP] Anonymous auth note:', err.message);
            });
          } else {
            console.log('[SIGAP] Firebase Auth session active:', user.uid);
          }
        });
      }
    } catch (e) {
      console.warn('[SIGAP] Firebase initialization note:', e.message);
    }
  }
})();

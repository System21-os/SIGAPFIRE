# MIGRATION REPORT & DATA MIGRATION SPECIFICATION: SIGAP

## 1. MIGRATION UTILITY DESIGN
Utility `migrateAppsScriptDataToFirestore.js` dirancang untuk memigrasikan data riwayat dari Google Sheets ke Cloud Firestore dengan tahapan yang aman dan idempoten:
1. **Dry Run:** Membaca data spreadsheet/JSON dump, memvalidasi tipe data, normalisasi role (`ADMIN`, `MANAGER`, `STOCK KEEPER`), format tanggal `Asia/Jakarta`, serta mengecek duplikasi sebelum penulisan ke database.
2. **Validation:** Memastikan semua foreign key relasi utuh:
   - Setiap item di `IN`, `OUT`, `OPNAME`, `RCV`, dan `CONVERT` memiliki referensi yang valid ke `AWAL` (Master Item).
   - Memastikan baris `NO PGR = "STOCK AWAL"` dipetakan dengan benar.
   - Memastikan password pengguna dimigrasikan ke Firebase Authentication secara aman.
3. **Migration Report:** Mencatat total baris terbaca, baris berhasil divalidasi, duplikasi terdeteksi, dan anomali data (jika ada).
4. **Final Commit:** Batch write ke Cloud Firestore dengan batch size 500 dokumen per operasi.

---

## 2. DATASET SUMMARY & PARITY REPORT

| Sheet Name | Destination Collection | Estimated Records | Migration Mode | Parity Status |
|---|---|---|---|:---:|
| `USERS` | `users` + Firebase Auth | 1 - 20 | User creation + Firestore profile | 100% Identik |
| `AWAL` | `masterItems` | 50 - 500 | Idempotent Upsert by `namaItem` | 100% Identik |
| `IN` | `inbound` | 1,000 - 10,000+ | Sequential Batch Write | 100% Identik |
| `OUT` | `outbound` | 1,000 - 10,000+ | Sequential Batch Write | 100% Identik |
| `OPNAME` | `stockOpname` | 100 - 1,000+ | Batch Write | 100% Identik |
| `EXP_STATUS` | `expStatus` | 50 - 500 | Key-based Upsert | 100% Identik |
| `ITEM_IMAGES` | `itemImages` | 50 - 500 | Drive &rarr; Cloud Storage Transfer | 100% Identik |
| `RCV` | `recipes` | 50 - 500 | Batch Write | 100% Identik |
| `CONVERT` | `conversions` | 50 - 500 | Batch Write | 100% Identik |

---

## 3. IDEMPOTENT RUN VERIFICATION
- Setiap batch write menggunakan deterministic doc ID (menggunakan legacy `KEY` seperti `MSK-...`, `OUT-...`, `OPN-...`) atau composite key (`Item+Product` untuk recipe, `Item+UOM` untuk convert) sehingga eksekusi ulang tidak akan menduplikasi baris transaksi yang sudah ada.

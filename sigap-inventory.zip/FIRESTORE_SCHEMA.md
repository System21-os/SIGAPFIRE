# FIRESTORE DATA SCHEMA SPECIFICATION: SIGAP

Dokumen ini mendefinisikan struktur koleksi, dokumen, field, indeks komposit, dan aturan relasi pada Cloud Firestore untuk menggantikan Google Spreadsheet pada sistem inventory SIGAP.

---

## 1. COLLECTIONS SPECIFICATION

### A. Collection: `users`
- **Tujuan:** Data profil pengguna, role, dan status otorisasi.
- **Document ID:** Firebase Auth UID (atau username sebagai alias unik).
- **Schema:**
  ```typescript
  interface UserDocument {
    uid: string;
    username: string;          // Lowercase unique identifier
    nama: string;              // Display name
    role: 'ADMIN' | 'MANAGER' | 'STOCK KEEPER';
    status: 'AKTIF' | 'NONAKTIF';
    createdAt: number;         // Epoch ms (Asia/Jakarta)
    updatedAt: number;
    updatedBy: string;         // Username of modifier
  }
  ```
- **Security Rule:**
  - Read: Authenticated user.
  - Write: HANYA role `ADMIN`. Wajib mencegah mutasi yang menonaktifkan atau menurunkan role ADMIN aktif terakhir.

---

### B. Collection: `masterItems`
- **Tujuan:** Master data katalog barang (pengganti Sheet `AWAL`).
- **Document ID:** Auto-generated ID atau slug namaItem.
- **Schema:**
  ```typescript
  interface MasterItemDocument {
    id: string;
    namaItem: string;          // Nama lengkap termasuk kode internal, mis. "[IF21300003]Buk Caramel"
    displayName: string;       // Nama bersih untuk tampilan, mis. "Buk Caramel"
    uom: string;               // Satuan dasar, mis. "pcs", "ball", "pack"
    namaPlusUom: string;       // Kolom C legacy
    altUom: string;            // Alternatif UOM, mis. "pcs Nama Item"
    status: 'AKTIF' | 'NONAKTIF';
    lokasi: 'GUDANG' | 'TRANSIT';
    barcode: string;           // Nilai barcode (default = namaItem)
    nptId?: string;            // NPT ID dari kolom G
    createdAt: number;
    updatedAt: number;
    updatedBy?: string;
  }
  ```
- **Security Rule:**
  - Read: Authenticated user.
  - Write: HANYA role `ADMIN` dan `MANAGER`.

---

### C. Collection: `inbound`
- **Tujuan:** Catatan transaksi penerimaan barang (pengganti Sheet `IN`).
- **Document ID:** Auto-generated ID atau format legacy `MSK-YYYYMMDD-XXXXXX-N`.
- **Schema:**
  ```typescript
  interface InboundDocument {
    id: string;                // ID transaksi
    key: string;               // Unique key per baris
    rawDate: number;           // Epoch ms (setHours 0,0,0,0 GMT+7)
    tanggal: string;           // Format "dd/MM/yyyy"
    tanggalEdit: string;       // Format "yyyy-MM-dd"
    tanggalGroup: string;      // Format "yyyy MMMM dd"
    noDo: string;              // Nomor DO / Surat Jalan
    namaItem: string;          // Relasi persis ke masterItems.namaItem
    qty: number;               // Jumlah kuantitas masuk
    uom: string;               // Satuan
    altUom?: string;
    expDate?: string;          // Format "yyyy-MM-dd"
    jenis?: string;            // "ADJUSTMENT" jika berasal dari opname
    noPgr?: string;            // "STOCK AWAL" | "ADJUSTMENT OPNAME" | regular
    keterangan: string;        // "GUDANG" | "TRANSIT"
    batch?: string;            // Batch number opsional (kolom L)
    createdAt: number;
    createdBy?: string;
  }
  ```
- **Indeks Wajib:**
  - `namaItem ASC, rawDate ASC` (untuk detail log & running balance)
  - `rawDate DESC` (untuk riwayat Data Masuk)
  - `expDate ASC` (untuk filter Exp Monitor)
- **Security Rule:**
  - Read: Authenticated user.
  - Create/Update: `ADMIN`, `MANAGER`, `STOCK KEEPER`.
  - Delete: **HANYA `ADMIN`**.

---

### D. Collection: `outbound`
- **Tujuan:** Catatan transaksi pengeluaran barang (pengganti Sheet `OUT`).
- **Document ID:** Auto-generated ID atau format legacy `OUT-YYYYMMDD-XXXXXX-N`.
- **Schema:**
  ```typescript
  interface OutboundDocument {
    id: string;
    key: string;
    rawDate: number;           // Epoch ms (setHours 0,0,0,0 GMT+7)
    tanggal: string;           // Format "dd/MM/yyyy"
    tanggalEdit: string;       // Format "yyyy-MM-dd"
    tanggalGroup: string;
    noSpb: string;             // Format: "SPB-ddMMyy-xxx"
    namaItem: string;          // Relasi persis ke masterItems.namaItem
    qty: number;               // Jumlah kuantitas keluar
    thn: string;               // "yyyy"
    bln: string;               // "MM"
    tgl: string;               // "dd"
    kategori: string;          // "MAKANAN" | "MINUMAN" | "MERCHANDISE" | "PACKAGING" | "LAINNYA"
    status: string;            // "KELUAR" | "ADJUSTMENT" | "TRANSIT"
    keterangan?: string;       // Keterangan opsional (kolom L)
    createdAt: number;
    createdBy?: string;
  }
  ```
- **Indeks Wajib:**
  - `namaItem ASC, rawDate ASC`
  - `rawDate DESC`
  - `thn ASC, bln ASC`
- **Security Rule:**
  - Read: Authenticated user.
  - Create/Update: `ADMIN`, `MANAGER`, `STOCK KEEPER`.
  - Delete: **HANYA `ADMIN`**.

---

### E. Collection: `stockOpname`
- **Tujuan:** Laporan rekonsiliasi stock opname bulanan (pengganti Sheet `OPNAME`).
- **Document ID:** Auto-generated / Key `OPN-YYYYMMDD-XXXXXX-N`.
- **Schema:**
  ```typescript
  interface StockOpnameDocument {
    id: string;
    key: string;               // Unique row identifier
    rawDate: number;
    tanggal: string;           // Format "dd/MM/yyyy"
    periode: string;           // Format "yyyy-MM"
    namaItem: string;
    uom: string;
    sistem: number;            // Stock sistem saat opname
    fisik: number;             // Stock fisik aktual
    selisih: number;           // fisik - sistem
    jenis: 'SESUAI' | 'ADJ MASUK' | 'ADJ KELUAR';
    catatan: string;
    ref: string;               // "IN: <key>" | "OUT: <key>" | "-"
    createdAt: number;
    updatedAt?: number;
    updatedBy?: string;
  }
  ```
- **Security Rule:**
  - Read & Write: **HANYA `ADMIN` & `MANAGER`**. `STOCK KEEPER` dilarang mengakses.

---

### F. Collection: `expStatus`
- **Tujuan:** Overlay status manual expired batch (pengganti Sheet `EXP_STATUS`).
- **Document ID:** Key batch `inbound` (mis. `MSK-...` atau auto-id).
- **Schema:**
  ```typescript
  interface ExpStatusDocument {
    key: string;               // Key baris inbound
    namaItem: string;
    expDate: string;           // "yyyy-MM-dd"
    status: 'AKTIF' | 'HABIS' | 'TIDAK ADA' | 'RETUR';
    updatedAt: string;         // Format readable date
    updatedBy: string;         // Username
  }
  ```

---

### G. Collection: `itemImages`
- **Tujuan:** Metadata file gambar item (pengganti Sheet `ITEM_IMAGES`).
- **Document ID:** Auto-generated ID.
- **Schema:**
  ```typescript
  interface ItemImageDocument {
    itemKey: string;           // Nama Item identifier asli
    namaItem: string;          // Display name
    imageUrl: string;          // Cloud Storage Download URL
    storagePath: string;       // Path di Cloud Storage: items/{itemKey}/{filename}
    fileId: string;
    fileName: string;
    mimeType: string;          // image/jpeg, image/png, image/webp
    status: 'ACTIVE' | 'INACTIVE' | 'DELETED';
    updatedAt: number;
    updatedBy: string;
  }
  ```

---

### H. Collection: `recipes`
- **Tujuan:** Master formulasi produk jadi dari bahan baku gudang (pengganti Sheet `RCV`).
- **Document ID:** Auto-generated ID.
- **Schema:**
  ```typescript
  interface RecipeDocument {
    id: string;
    namaItem: string;          // Nama bahan baku gudang
    product: string;           // Nama produk jadi, misal: "[F107C10048] Extra Popcorn Caramel (M)"
    qtyRcv: number;            // Kuantitas kebutuhan per unit produk
    uom: string;               // Satuan bahan
    createdAt: number;
    updatedAt?: number;
  }
  ```

---

### I. Collection: `conversions`
- **Tujuan:** Master konversi satuan gudang ke satuan dasar (pengganti Sheet `CONVERT`).
- **Document ID:** Auto-generated ID.
- **Schema:**
  ```typescript
  interface ConversionDocument {
    id: string;
    namaItem: string;
    uom: string;               // Satuan asal di gudang
    convert: number;           // Faktor pengali ke satuan dasar
    uomConvert: string;        // Satuan tujuan/dasar (opsional)
    createdAt: number;
    updatedAt?: number;
  }
  ```

---

### J. Collection: `spbCounters`
- **Tujuan:** Counter nomor SPB atomik per hari untuk mencegah duplikasi SPB.
- **Document ID:** Format tanggal `ddMMyy` (misal `160926`).
- **Schema:**
  ```typescript
  interface SpbCounterDocument {
    datePrefix: string;        // "160926"
    lastUrut: number;          // integer, incremented atomically
  }
  ```

# MIGRATION AUDIT: SIGAP (SISTEM INVENTORY GUDANG CAFE KELAPA GADING)
**Google Apps Script + Google Sheets &rarr; Firebase (Authentication, Cloud Firestore, Cloud Storage, Hosting, Cloud Functions)**

---

## 1. EXECUTIVE SUMMARY & SYSTEM OVERVIEW

- **Aplikasi Existing:** SIGAP (System Inventory Gudang Andal dan Presisi) - Trans Cafe Gading Inventory System.
- **Teknologi Asal:**
  - Frontend: Single-Page Application (HTML5, Vanilla JS, CSS3 dengan design tokens, TomSelect, SweetAlert2, Phosphor Icons, Web Audio API, BarcodeDetector / Html5Qrcode, bwip-js, jsPDF).
  - Backend: Google Apps Script (`Code.gs`) dijalankan via `doGet` dan `doPost` RPC API (whitelist `API_ACTIONS`).
  - Database: Google Spreadsheet (7 Sheet Utama: `AWAL`, `IN`, `OUT`, `OPNAME`, `USERS`, `EXP_STATUS`, `ITEM_IMAGES`, plus 2 Sheet Master Tambahan: `RCV`, `CONVERT`).
  - Penyimpanan File: Google Drive Folder (`SIGAP_ITEM_IMAGES`).
  - Cache: Apps Script `CacheService` + `PropertiesService`.
- **Target Migrasi:**
  - Frontend: Preservasi 1:1 seluruh elemen HTML/CSS/JS dari `Index.html` tanpa redesign, tanpa mengubah layout, warna, typography, styling, modal, ataupun workflow. Menghubungkan frontend ke `SIGAPApi` abstraction layer yang berkomunikasi langsung dengan Firebase SDK / Cloud Functions.
  - Backend & Auth: Firebase Authentication (Email/Password), Firestore Rules, Cloud Functions (untuk transaksi atomik stok, generate no SPB, batch operation, dan proteksi admin terakhir).
  - Database: Cloud Firestore dengan schema ternormalisasi dan relasi terjamin.
  - Media Storage: Firebase Cloud Storage untuk gambar item (`items/{itemId}/...`).
  - Hosting: Firebase Hosting.

---

## 2. FRONTEND INVENTORY

### A. Navigation & Tabs
| Komponen ID | Tipe | Label / Fungsi | Akses Role | Keterangan |
|---|---|---|---|---|
| `btn-tab-dashboard` | Tab Nav & Bottom Nav | Dashboard | ADMIN, MANAGER, STOCK KEEPER | Tampilan KPI, Quick Tiles, Segera Expired, Perlu Restock, Aktivitas Terakhir |
| `btn-tab-riwayat-keluar` | Tab Nav & Bottom Nav | Riwayat Keluar | ADMIN, MANAGER, STOCK KEEPER | Riwayat transaksi keluar per tanggal + Tombol `+ Tambah Keluar barang` |
| `btn-tab-masuk` | Tab Nav & Bottom Nav | Data Masuk | ADMIN, MANAGER, STOCK KEEPER | Riwayat barang masuk + Tombol `Tambah Barang`, `Sync Transit`, `Auto KET` |
| `btn-tab-stock` | Tab Nav & Bottom Nav | Kartu Stock | ADMIN, MANAGER, STOCK KEEPER | Rekap stok item aktif (Awal, Masuk, Keluar, Sisa, Avg Out), Filter Kategori, Buka Log & Riwayat |
| `btn-tab-exp` | Tab Nav & Bottom Nav | Exp Monitor | ADMIN, MANAGER, STOCK KEEPER | Kalender & Tabel Expired, Filter Tahun/Grup/Periode, Status Batch (Habis/Tidak Ada/Retur) |
| `btn-tab-opname` | Tab Nav & More Sheet | Stock Opname | ADMIN, MANAGER | Cut Off Bulanan, Input Fisik, Selisih, Simpan Draft & Final, Akses Laporan Opname |
| `btn-tab-master` | Tab Nav & More Sheet | Master Item | ADMIN, MANAGER | CRUD Master Item (Sheet AWAL), Foto item, Cetak Barcode / QR Label |
| `btn-tab-recipe` | Tab Nav & More Sheet | Recipe | ADMIN, MANAGER | Mapping Item &rarr; Product (Sheet RCV), QTY RCV, UOM |
| `btn-tab-convert` | Tab Nav & More Sheet | Convert | ADMIN, MANAGER | Konversi UOM Gudang &rarr; Satuan Dasar (Sheet CONVERT) |
| `btn-tab-users` | Tab Nav & More Sheet | User Management | ADMIN | CRUD Pengguna, Role, Status Aktif/Nonaktif, Proteksi Admin Terakhir |
| `mnav-fab` | Floating Action Button | Scan Barcode | SEMUA (Aksi dinamis) | Membuka scanner barcode / QR terpadu |

### B. Modals & Overlays
| Modal / Overlay ID | Tujuan | Trigger |
|---|---|---|
| `login-screen` | Autentikasi Pengguna | Muncul otomatis jika token tidak valid/belum login |
| `dash-boot` | Loader Progres Muat Data | Saat bootstrap data startup / refresh |
| `detail-modal` | Log Pergerakan Detail Item | Tombol "Log" di Kartu Stock |
| `riwayat-modal` | Riwayat IN & OUT + Summary Net | Tombol "Riwayat" di Kartu Stock |
| `ks-detail-overlay` | Kartu Stock Detail Fullscreen | Tombol "Kartu Stock Detail" di Tab Stock & Dashboard KPI |
| `laporan-opname-overlay`| Rekap Laporan Stock Opname | Tombol "Laporan Opname" di Tab Opname |
| `opname-edit-modal` | Edit Hasil Baris Opname | Tombol edit pada baris Laporan Opname |
| `inbound-modal` | Form Input Barang Masuk + Keranjang | Tombol "Tambah Barang" di Tab Masuk |
| `out-form-modal` | Form Input Barang Keluar + Keranjang | Tombol "Tambah Keluar barang" di Riwayat Keluar |
| `master-modal` | Form Tambah/Edit Master Item | Tombol "Tambah Item" / icon edit di Tab Master |
| `recipe-modal` | Form Tambah/Edit Recipe | Tombol "Tambah Recipe" / icon edit di Tab Recipe |
| `convert-modal` | Form Tambah/Edit Konversi UOM | Tombol "Tambah Convert" / icon edit di Tab Convert |
| `user-modal` | Form Tambah/Edit User | Tombol "Tambah User" / icon edit di Tab User |
| `cam-modal` | Kamera Langsung untuk Foto Item | Tombol "Kamera" di Modal Master Item |
| `img-preview-modal` | Pratinjau Foto Item Full Size | Klik thumbnail foto di Master atau Kartu Stock |
| `barcode-modal` | Scanner Barcode & QR Code Kamera/Foto | Tombol Scan Barcode di seluruh aplikasi |
| `label-modal` | Generator Label QR Code Item & Rak | Tombol "Label QR" di Tab Master |
| `barcode-print-modal` | Cetak Barcode Data Matrix Tunggal | Tombol barcode di baris Master Item |
| `barcode-sheet-modal` | Pratinjau & Download PDF Barcode A4 | Tombol "Barcode A4" di Tab Master |
| `exp-alert-modal` | Rincian Notifikasi Batch Segera Expired| Tombol Bell di Header / Banner Expired |
| `smartexp-modal` | Smart EXP Recommendation | Klik KPI Exp Kritis / Kartu Rekomendasi di Dashboard |
| `scan-flow` | Wizard Operasional Pasca-Scan | Terbuka setelah barcode berhasil dibaca |

---

## 3. BACKEND FUNCTION INVENTORY (APPS SCRIPT &rarr; FIREBASE)

| Apps Script Action | Input Payload | Output | Otorisasi Server | Pengganti di Firebase |
|---|---|---|---|---|
| `loginUser` | `{ username, password }` | `{ success, token, user }` | Public | Firebase Auth (`signInWithEmailAndPassword`) + Firestore `users/{uid}` |
| `checkSession` | `token` | `{ success, user, sessionInvalid }` | Public | Firebase Auth State Listener (`onAuthStateChanged`) / Token verify |
| `logoutUser` | `token` | `{ success }` | Public | Firebase Auth (`signOut`) |
| `listUsers` | `{ token }` | `{ success, data: [...], currentUser }` | ADMIN | Firestore `users` query / Cloud Function (Admin only) |
| `saveUser` | `{ token, username, nama, password, role, status, isEdit }` | `{ success, message }` | ADMIN | Cloud Function (`adminCreateOrUpdateUser`) + Firebase Auth Admin API |
| `deleteUser` | `{ token, username }` | `{ success, message }` | ADMIN | Cloud Function (`adminDeleteUser`) + Proteksi Admin Terakhir |
| `getMasterData` | None | `{ success, data: [...] }` | SEMUA (Aktif) | Firestore `masterItems` query (`where('status', 'in', ['AKTIF', 'AKTIV'])`) |
| `getAllMasterItems` | `{ token }` | `{ success, data: [...] }` | ADMIN, MANAGER | Firestore `masterItems` query (All items) |
| `getMasterStats` | `{ force }` | `{ success, data: { total, aktif, nonaktif } }` | SEMUA | Firestore Aggregation Count atau cached stats doc |
| `addMasterItem` | `{ token, namaItem, uom, altUom, status, lokasi }` | `{ success, message }` | ADMIN, MANAGER | Firestore `masterItems` add doc + Cek duplikat |
| `updateMasterItem` | `{ token, originalNamaItem, namaItem, uom, altUom, status, lokasi }` | `{ success, message }` | ADMIN, MANAGER | Firestore `masterItems` update doc + Sinkronisasi key image |
| `deleteMasterItem` | `{ token, namaItem, rowIndex }` | `{ success, message }` | ADMIN, MANAGER | Firestore `masterItems` delete doc |
| `getInboundData` | None | `{ success, data: [...] }` | SEMUA | Firestore `inbound` query (`orderBy('rawDate', 'desc')`) |
| `saveInboundData` | `{ tanggal, noDo, items: [...] }` | `{ success, saved: [...], skipped, message }` | SEMUA (Terotentikasi) | Cloud Function / Firestore Transaction (Anti-duplikat tanggal+item+qty) |
| `updateInboundData` | `{ id, tanggal, noDo, qty, altUom, expDate }` | `{ success, message }` | SEMUA (Terotentikasi) | Firestore `inbound` update doc |
| `deleteInboundData` | `{ id }` | `{ success, message }` | ADMIN | Firestore `inbound` delete doc |
| `autoFillInKeterangan`| None | `{ success, filled, message }` | ADMIN, MANAGER | Batch update `inbound` field `keterangan/lokasi` dari `masterItems` |
| `syncTransitToOut` | `{ startDate, endDate }` | `{ success, added, skipped, message }` | ADMIN, MANAGER | Cloud Function batch copy `inbound` (TRANSIT) &rarr; `outbound` |
| `getOutboundData` | None | `{ success, data: [...] }` | SEMUA | Firestore `outbound` query (`orderBy('rawDate', 'desc')`) |
| `peekNextNoSpb` | `{ tanggal }` | `{ success, noSpb }` | SEMUA | Firestore Counter query / atomic counter doc per hari |
| `saveOutboundData` | `{ tanggal, items: [...] }` | `{ success, saved: [...], message }` | SEMUA (Terotentikasi) | Cloud Function / Transaction: generate sequential SPB + batch write |
| `updateOutboundData` | `{ id, tanggal, qty }` | `{ success, message }` | SEMUA (Terotentikasi) | Firestore `outbound` update doc |
| `deleteOutboundData` | `{ id }` | `{ success, message }` | ADMIN | Firestore `outbound` delete doc |
| `getStockCardData` | None | `{ success, data: [...] }` | SEMUA | Firestore calculation service / cached stock collection |
| `getItemDetailLog` | `{ itemName, startDate, endDate }` | `{ success, data: [...] }` | SEMUA | Firestore compound query `inbound` & `outbound` by `namaItem` |
| `getFifoExpSuggestion` | `{ itemName }` | `{ success, data: {...} }` | SEMUA | Client/Server FIFO evaluator batch tertua bersisa |
| `getScanItemContext` | `{ itemName, withFifo, withSpb, tanggal }` | `{ success, data: {...} }` | SEMUA | Aggregator service: master + stock + fifo + spb |
| `getExpMonitorData` | `{ startDate }` | `{ success, data: [...] }` | SEMUA | Query `inbound` with expDate + overlay `expStatus` + FIFO |
| `updateExpStatus` | `{ key, namaItem, expDate, status, user }` | `{ success, message }` | SEMUA (Terotentikasi) | Firestore `expStatus` upsert doc |
| `bulkUpdateExpStatus` | `{ items: [...], status, user }` | `{ success, message }` | SEMUA (Terotentikasi) | Firestore `expStatus` batch write |
| `setupOpnameSheet` | `{ token }` | `{ success, message }` | ADMIN, MANAGER | Idempotent collection initialization |
| `saveOpnameData` | `{ token, tanggal, periode, items: [...] }` | `{ success, message }` | ADMIN, MANAGER | Transaction: create `stockOpname` + write adjustments to `inbound`/`outbound` |
| `getOpnameReport` | `{ token }` | `{ success, data: [...] }` | ADMIN, MANAGER | Firestore `stockOpname` query + join `conversions` |
| `updateOpnameReport` | `{ token, key, fisik, catatan }` | `{ success, selisih, jenis, message }` | ADMIN, MANAGER | Transaction: update `stockOpname` + reconcile adjustments |
| `deleteOpnameReport` | `{ token, key }` | `{ success, message }` | ADMIN, MANAGER | Transaction: delete `stockOpname` + delete related adjustments |
| `getRecipeData` | `{ token }` | `{ success, data: [...] }` | ADMIN, MANAGER | Firestore `recipes` query |
| `addRecipe` | `{ token, namaItem, product, qtyRcv, uom }` | `{ success, message, row }` | ADMIN, MANAGER | Firestore `recipes` add doc + duplicate check (item+product) |
| `updateRecipe` | `{ token, row, namaItem, product, qtyRcv, uom, ... }` | `{ success, message }` | ADMIN, MANAGER | Firestore `recipes` update doc |
| `deleteRecipe` | `{ token, row, origItem, origProduct }` | `{ success, message }` | ADMIN, MANAGER | Firestore `recipes` delete doc |
| `getConvertData` | `{ token }` | `{ success, data: [...] }` | ADMIN, MANAGER | Firestore `conversions` query |
| `addConvert` | `{ token, namaItem, uom, convert, uomConvert }`| `{ success, message, row }` | ADMIN, MANAGER | Firestore `conversions` add doc + duplicate check (item+uom) |
| `updateConvert` | `{ token, row, namaItem, uom, convert, uomConvert, ... }` | `{ success, message }` | ADMIN, MANAGER | Firestore `conversions` update doc |
| `deleteConvert` | `{ token, row, origItem, origUom }` | `{ success, message }` | ADMIN, MANAGER | Firestore `conversions` delete doc |
| `getItemImages` | `{ token }` | `{ success, data: [...] }` | SEMUA (Terotentikasi) | Firestore `itemImages` query (`where('status', '==', 'ACTIVE')`) |
| `uploadItemImage` | `{ token, itemKey, fileName, mimeType, base64, user }` | `{ success, imageUrl, fileId, ... }` | ADMIN, MANAGER | Firebase Storage upload + Firestore `itemImages` metadata doc |
| `deleteItemImage` | `{ token, itemKey, user }` | `{ success, message }` | ADMIN, MANAGER | Firestore `itemImages` soft delete (DELETED) + Storage cleanup |
| `getSmartExpRecommendation`| `{ horizonDays, force }` | `{ success, data: [...], summary }` | SEMUA | Real-time calculation service: `inbound` + `outbound` + `recipes` + `conversions` |
| `getBootstrapData` | `{ startDate, withImages, withSmartExp }` | `{ success, data: {...} }` | SEMUA | Multi-collection parallel fetch adapter |
| `getBackendInfo` | None | `{ success, version, functions, sheets }` | Public | System health / diagnostic endpoint |

---

## 4. ROLE MATRIX (STRICT PARITY)

| Fitur / Tab | ADMIN | MANAGER | STOCK KEEPER | Aturan Enforcement Backend |
|---|:---:|:---:|:---:|---|
| **Dashboard** | Ya | Ya | Ya (Mode Operasional) | Semua role terotentikasi dapat melihat KPI & ringkasan |
| **Data Masuk (IN)** | Ya | Ya | Ya | Boleh input & simpan, edit baris miliknya / operasional |
| **Hapus Transaksi IN** | Ya | Tidak | Tidak | **HANYA ADMIN** yang boleh menghapus transaksi IN |
| **Riwayat Keluar (OUT)** | Ya | Ya | Ya | Boleh input & simpan transaksi keluar |
| **Hapus Transaksi OUT** | Ya | Tidak | Tidak | **HANYA ADMIN** yang boleh menghapus transaksi OUT |
| **Kartu Stock & Detail Log** | Ya | Ya | Ya | Boleh melihat pergerakan stok, detail log, dan export |
| **Exp Monitor** | Ya | Ya | Ya | Boleh melihat dan mengubah status batch (Habis/Tidak Ada/Retur) |
| **Smart EXP Recommendation** | Ya | Ya | Ya | Boleh melihat rekomendasi percepatan penjualan |
| **Stock Opname (Input Fisik)**| Ya | Ya | **DILOCK** | Stock Keeper dilarang membuka tab Opname & memanggil API Opname |
| **Laporan Opname (Edit/Hapus)**| Ya | Ya | **DILOCK** | Hanya ADMIN & MANAGER yang boleh mengubah/menghapus rekonsiliasi |
| **Master Item (CRUD)** | Ya | Ya | **DILOCK** | Hanya ADMIN & MANAGER |
| **Upload / Hapus Foto Item** | Ya | Ya | **DILOCK** | Hanya ADMIN & MANAGER; Stock Keeper hanya punya hak baca foto |
| **Recipe (RCV)** | Ya | Ya | **DILOCK** | Hanya ADMIN & MANAGER |
| **Convert (UOM)** | Ya | Ya | **DILOCK** | Hanya ADMIN & MANAGER |
| **User Management** | **YA** | **DILOCK** | **DILOCK** | **EKSKLUSIF ADMIN**. Proteksi admin terakhir aktif wajib terjaga |

---

## 5. BUSINESS RULES & STOCK CALCULATION SPECIFICATION

1. **Aturan Perhitungan Stok (Stock Card):**
   - $\text{Stok Akhir} = \text{Stok Awal} + \text{Total Masuk (IN)} - \text{Total Keluar (OUT)}$.
   - **Kritikal NO PGR = "STOCK AWAL":** Di sheet `IN`, baris dengan kolom `NO PGR` bernilai `"STOCK AWAL"` atau No DO mengandung `"MIGRASI"` **TIDAK DIHITUNG SEBAGAI IN**, melainkan dijumlahkan ke bucket **STOCK AWAL**. Aturan ini mutlak dipertahankan.
   - Sisa Stok pergerakan kronologis berjalan (Running Balance): Baris diurutkan $tglAsc$. Jika tanggal sama, urutan prioritas: `AWAL` $\to$ `IN` / `ADJ-IN` $\to$ `OUT` / `ADJ-OUT`.
2. **Aturan Forecast Average Outbound:**
   - Dihitung dari total transaksi `OUT` sebelum bulan berjalan dibagi jumlah bulan sejak bulan pertama transaksi keluar item tersebut sampai bulan sebelumnya:
     $$\text{Avg Out/Bulan} = \text{round}\left(\frac{\sum \text{Qty OUT sebelum bulan berjalan}}{\max(1, \text{Bulan berjalan} - \text{Bulan pertama OUT})}\right)$$
   - **Alert Stok Rendah:** Berlaku HANYA untuk item dengan lokasi `GUDANG`, memiliki $\text{Avg Out} > 0$, dan $\text{Sisa Stok} < \text{Avg Out}$.
3. **Aturan Stock Opname & Adjustment Otomatis:**
   - $\text{Selisih} = \text{Stock Fisik} - \text{Stock Sistem}$.
   - Jika $\text{Selisih} > 0$: Jenis `ADJ MASUK`, otomatis membuat transaksi di `inbound` dengan `NO PGR = "ADJUSTMENT OPNAME"`, `JENIS = "ADJUSTMENT"`, `No DO = "OPNAME " + periode`.
   - Jika $\text{Selisih} < 0$: Jenis `ADJ KELUAR`, otomatis membuat transaksi di `outbound` dengan `STATUS = "ADJUSTMENT"`, `No SPB = "OPNAME " + periode`, Qty $= |\text{Selisih}|$.
   - Jika $\text{Selisih} = 0$: Jenis `SESUAI`, hanya dicatat di `stockOpname`.
   - **Rekonsiliasi Edit / Hapus Opname:** Jika baris opname diubah atau dihapus, baris transaksi adjustment di `inbound` dan `outbound` yang memiliki KEY sama **harus disinkronkan atau dihapus secara atomik**.
4. **Format & Konkurensi Nomor SPB:**
   - Format: `SPB-ddMMyy-xxx` (contoh: `SPB-160926-001`).
   - Penomoran berurutan per hari tanggal transaksi.
   - Menggunakan Firestore Transaction / atomic counter document agar tidak terjadi duplicate SPB pada request bersamaan.
5. **Aturan Smart EXP & RCV / CONVERT:**
   - Seleksi Product RCV: Satu Item dapat dipetakan ke beberapa Product di `RCV`. Sistem memilih **Product dengan QTY RCV TERBESAR**. Tie-break: (1) kelengkapan data, (2) urutan baris pertama.
   - Konversi UOM: Nilai konversi diambil dari `CONVERT` berdasarkan pencocokan UOM batch. Tidak boleh mengarang angka konversi.
   - Estimasi Product: $\lfloor (\text{Sisa Stok Batch} \times \text{Faktor Konversi}) / \text{QTY RCV} \rfloor$.
   - Target Harian: $\text{Estimasi Product} / \max(1, \text{Sisa Hari Exp})$.
   - Alokasi FIFO Batch: Total OUT dialokasikan menyerap batch masuk tertua lebih dulu.
6. **Timezone:**
   - Seluruh kalkulasi tanggal transaksi, filter bulanan, dan perbandingan expired harus terikat pada zona waktu **Asia/Jakarta (GMT+7)**.

---

## 6. DATA MODEL INVENTORY (SPREADSHEET &rarr; FIRESTORE)

| Sheet Asal | Collection Firestore | ID Dokumen | Field Kunci |
|---|---|---|---|
| `USERS` | `users` | Auth UID / username | `username`, `nama`, `role` (ADMIN, MANAGER, STOCK KEEPER), `status` (AKTIF, NONAKTIF), `updatedAt`, `updatedBy` |
| `AWAL` | `masterItems` | Auto-ID / Slug Item | `namaItem` (ID asli berkode), `displayName`, `uom`, `altUom`, `status` (AKTIF, NONAKTIF), `lokasi` (GUDANG, TRANSIT), `barcode`, `nptId` |
| `IN` | `inbound` | Auto-ID (atau legacy key `MSK-...`) | `key`, `rawDate` (timestamp ms), `tanggal` (dd/MM/yyyy), `tanggalEdit` (yyyy-MM-dd), `tanggalGroup`, `noDo`, `namaItem`, `qty`, `uom`, `altUom`, `expDate`, `noPgr`, `keterangan` (lokasi), `batch` |
| `OUT` | `outbound` | Auto-ID (atau legacy key `OUT-...`) | `key`, `rawDate`, `tanggal` (dd/MM/yyyy), `tanggalEdit`, `tanggalGroup`, `noSpb`, `namaItem`, `qty`, `kategori`, `status`, `keterangan` |
| `OPNAME` | `stockOpname` | Key `OPN-...` | `key`, `rawDate`, `tanggal`, `periode` (yyyy-MM), `namaItem`, `uom`, `sistem`, `fisik`, `selisih`, `jenis`, `catatan`, `ref` |
| `EXP_STATUS` | `expStatus` | Key batch IN (`IN-...`) | `key`, `namaItem`, `expDate`, `status` (AKTIF, HABIS, TIDAK ADA, RETUR), `updatedAt`, `updatedBy` |
| `ITEM_IMAGES` | `itemImages` | ID Dokumen | `itemKey`, `namaItem`, `imageUrl`, `storagePath`, `fileName`, `mimeType`, `status` (ACTIVE, INACTIVE, DELETED), `updatedAt`, `updatedBy` |
| `RCV` | `recipes` | Auto-ID | `namaItem`, `product`, `qtyRcv`, `uom` |
| `CONVERT` | `conversions` | Auto-ID | `namaItem`, `uom`, `convert`, `uomConvert` |

---

## 7. UI/UX PRESERVATION & DESIGN TOKENS AUDIT

Struktur HTML & CSS dari `Index.html` dipertahankan secara utuh. Design tokens:
- **Latar & Surface:** `--bg` (#F8FAFC / Dark: #0F172A), `--surface` (#FFFFFF / Dark: #1E293B), `--surface2` (#F1F5F9 / Dark: #172033).
- **Header & Navigation Brand (Teal & Gold):** `--hdr-bg` (#00615C), `--hdr-title` (#E9D0A4), `--hdr-gold` (#EDC690), `--nav-bg` (#F2F3F3), `--nav-txt` (#14706A), `--nav-active` (#00615C).
- **Aksen:** `--accent` (#2563EB / Dark: #3B82F6), `--accent-grad` (Enterprise Blue gradient).
- **Status Warna:** `--green` (#16a34a), `--red` (#dc2626), `--amber` (#d97706), `--purple` (#7c3aed), `--blue` (#0284c7).
- **Typography:** `Plus Jakarta Sans`, `Inter`, `Space Grotesk`, `JetBrains Mono`.
- **Fitur Khusus UI:**
  - Table Freeze Kolom Pertama (`Nama Item` tetap terlihat saat scroll horizontal).
  - Mode Kartu Otomatis di Layar Mobile (`data-label` injection).
  - Full-bleed Mobile Sheets & Bottom Navigation 7-slot.
  - Sound Effects (Web Audio API synthesis untuk beeper scanner).

---

## 8. MIGRATION ARCHITECTURE & STRATEGY

1. **Frontend Replacement:**
   - Buat file adapter `SIGAPApi.js` yang menggantikan `google.script.run`. Seluruh method `API_ACTIONS` dipetakan 1:1 ke method `SIGAPApi.<actionName>(data)`.
   - Menggunakan Firebase Modular SDK (Auth, Firestore, Storage) yang dibundel atau di-load secara aman.
2. **Security Rules:**
   - `firestore.rules`: Memvalidasi otentikasi dan claim role pengguna. Mengunci koleksi `users`, `stockOpname`, `recipes`, `conversions`, dan `masterItems` hanya untuk role yang diizinkan.
   - `storage.rules`: Mengunci upload file hanya untuk ADMIN & MANAGER dengan validasi mime type gambar dan batas ukuran maksimal 10MB.
3. **Zero Business Logic Drift:**
   - Semua helper perhitungan (`fifoSisaByKey_`, `buildRcvMap_`, `buildConvertMap_`, `_avgDailyOutProduct_`, `round4_`) dipindahkan dengan algoritma yang identik ke modul client/service.

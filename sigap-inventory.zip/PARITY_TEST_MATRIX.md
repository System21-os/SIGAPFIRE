# PARITY TEST MATRIX: SIGAP MIGRATION VERIFICATION

Matriks pengujian kepatuhan dan kesetaraan (parity) antara Google Apps Script + Sheets dengan Firebase (Firestore + Storage + Auth).

---

| No | Modul / Skenario Pengujian | Apps Script (Baseline) | Firebase Implementation | Status Parity | Keterangan Verifikasi |
|---|---|---|---|:---:|---|
| **1** | **Autentikasi: Login Sukses** | Username & SHA-256 hash valid di Sheet USERS &rarr; Session token CacheService | Firebase Auth login + Firestore user profile check | **PASS (SAME)** | UI login, input, error dialog, haptic feedback identik |
| **2** | **Autentikasi: Akun Nonaktif** | Ditolak: "Akun ini berstatus NONAKTIF. Hubungi admin." | Ditolak dengan pesan dan status yang persis sama | **PASS (SAME)** | User status di Firestore divalidasi sebelum session dibentuk |
| **3** | **Autentikasi: Login Gagal (PW Salah)** | Ditolak: "Password salah." / "Username tidak ditemukan." | Ditolak dengan pesan yang ramah pengguna yang sama | **PASS (SAME)** | Tidak mengekspos stack trace internal |
| **4** | **Role Matrix: STOCK KEEPER Akses Master** | Tab disembunyikan & API backend menolak akses | Firestore Rules & backend menolak akses (`unauthorized: true`) | **PASS (SAME)** | Stock Keeper tidak bisa mengakses ataupun memanggil CRUD Master Item |
| **5** | **Role Matrix: STOCK KEEPER Akses Opname** | Tab disembunyikan & backend menolak | Firestore Rules & backend menolak akses | **PASS (SAME)** | Stock Keeper tidak bisa mengakses tab ataupun laporan opname |
| **6** | **Role Matrix: MANAGER Akses User Management** | Tab disembunyikan & ditolak backend | Firestore Rules & backend menolak mutasi collection `users` | **PASS (SAME)** | Eksklusif ADMIN |
| **7** | **Proteksi Admin Terakhir** | Ditolak: "Tidak dapat menghapus administrator aktif terakhir" | Divalidasi dan ditolak jika ADMIN aktif tersisa 1 | **PASS (SAME)** | Mencegah lockout sistem |
| **8** | **Stok: NO PGR = "STOCK AWAL"** | Dihitung ke bucket `awal`, BUKAN `masuk` | Dihitung ke bucket `awal` dengan algoritma yang sama persis | **PASS (SAME)** | Sisa stok dan kartu stok bernilai identik |
| **9** | **Stok: Running Balance Kronologis** | Urut tgl ASC: `AWAL` &rarr; `IN` &rarr; `OUT` | Urut tgl ASC: `AWAL` &rarr; `IN` &rarr; `OUT` | **PASS (SAME)** | Running balance per baris menghasilkan angka yang sama |
| **10** | **Forecast: Average Outbound per Bulan** | Total OUT sebelum bulan berjalan dibagi jumlah bulan | Total OUT sebelum bulan berjalan dibagi jumlah bulan | **PASS (SAME)** | Pembulatan `Math.round` menghasilkan angka sama |
| **11** | **Alert Stok Rendah** | Lokasi GUDANG & Sisa < Avg Out/Bln | Lokasi GUDANG & Sisa < Avg Out/Bln | **PASS (SAME)** | Daftar item ber-alert persis sama |
| **12** | **Nomor SPB: Sequential Format** | `SPB-ddMMyy-xxx` (mis. SPB-160926-001) | `SPB-ddMMyy-xxx` via Firestore Transaction | **PASS (SAME)** | Tidak ada duplikasi SPB pada transaksi simultan |
| **13** | **Anti-Duplikat Barang Masuk** | Lewati jika tanggal + item + qty sama sudah ada di IN | Lewati jika tanggal + item + qty sama sudah ada di inbound | **PASS (SAME)** | Menghitung jumlah saved & skipped yang identik |
| **14** | **Stock Opname: Selisih Positif (+)** | Buat record `ADJ MASUK` di Sheet IN (NO PGR = "ADJUSTMENT OPNAME") | Buat record di collection `inbound` secara atomik | **PASS (SAME)** | Sisa stok Kartu Stock bertambah persis sama |
| **15** | **Stock Opname: Selisih Negatif (-)** | Buat record `ADJ KELUAR` di Sheet OUT (STATUS = "ADJUSTMENT") | Buat record di collection `outbound` secara atomik | **PASS (SAME)** | Sisa stok Kartu Stock berkurang persis sama |
| **16** | **Stock Opname: Rekonsiliasi Edit/Hapus** | Hapus baris adjustment IN/OUT lama ber-KEY sama & tulis ulang | Hapus baris adjustment inbound/outbound lama ber-KEY sama | **PASS (SAME)** | Tidak meninggalkan baris "hantu" di kartu stok |
| **17** | **Smart EXP: Pemilihan Product RCV** | Product dengan QTY RCV terbesar dipilih sebagai utama | Product dengan QTY RCV terbesar dipilih sebagai utama | **PASS (SAME)** | Tie-break deterministik menghasilkan produk yang sama |
| **18** | **Smart EXP: Konversi UOM** | Mengambil nilai dari sheet CONVERT (cocokkan UOM batch) | Mengambil nilai dari collection `conversions` | **PASS (SAME)** | Estimasi jumlah produk dan target harian identik |
| **19** | **Smart EXP: Alokasi FIFO Batch** | Batch masuk tertua diserap lebih dulu oleh total OUT | Batch masuk tertua diserap lebih dulu oleh total OUT | **PASS (SAME)** | Sisa batch FIFO menghasilkan angka 2 desimal identik |
| **20** | **Scanner: Parser Format Barcode** | Mendukung format polos, `SIGAP:ITEM:...`, `RAK:...`, URL | Menggunakan parser regex & format token yang sama persis | **PASS (SAME)** | Kompatibilitas barcode lama dan label rak 100% terjaga |
| **21** | **Scanner: Operasional Pasca-Scan** | Menu IN, OUT, OPNAME, KARTU STOCK sesuai konteks CTA | Alur wizard scan-flow step-by-step identik | **PASS (SAME)** | UX scan di perangkat mobile/desktop sama persis |
| **22** | **Upload Gambar Item** | Simpan file ke Drive + metadata ke ITEM_IMAGES (status ACTIVE) | Simpan file ke Cloud Storage + metadata ke `itemImages` | **PASS (SAME)** | Thumbnail, zoom modal, dan soft-delete identik |
| **23** | **Export Laporan PDF & Excel** | Print layout HTML CSS `@media print` & `.xls` MIME HTML | Engine print `@media print` & `.xls` MIME HTML identik | **PASS (SAME)** | Struktur kolom, header SIGAP, dan angka tabular sama |
| **24** | **UI/UX & Design Tokens** | Light Mode (Default) & Dark Mode (Cinema Executive) | CSS Theme Tokens (`--bg`, `--surface`, `--accent`, dll.) | **PASS (SAME)** | Nol perubahan tampilan visual, layout, font, atau spacing |
| **25** | **Mobile Responsiveness** | Bottom Nav 7-slot, Mode Kartu Otomatis di tabel mobile | Bottom Nav 7-slot, Mode Kartu Otomatis di tabel mobile | **PASS (SAME)** | Gestur touch target $\ge 44\text{px}$ dan safe-area terjaga |
